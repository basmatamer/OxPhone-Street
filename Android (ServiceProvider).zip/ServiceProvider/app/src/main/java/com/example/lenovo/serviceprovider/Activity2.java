package com.example.lenovo.serviceprovider;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.camera2.CameraManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

public class Activity2 extends AppCompatActivity implements View.OnClickListener{

    Button next_button;
    Button resend_button_code;

    EditText digit1;
    EditText digit2;
    EditText digit3;
    EditText digit4;
    EditText digit5;
    EditText digit6;


    String inputted_code;
    String registered_email;
    String registered_name;
    String status;

    String admin_ID;

    SharedPreferences shared;

    String IP_address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        IP_address = "10.40.39.125";

        next_button = (Button) findViewById(R.id.next_button);
        resend_button_code = (Button)findViewById(R.id.resend_button);

        digit1 = (EditText)findViewById(R.id.digitl);
        digit2 = (EditText)findViewById(R.id.digit2);
        digit3 = (EditText)findViewById(R.id.digit3);
        digit4 = (EditText)findViewById(R.id.digit4);
        digit5 = (EditText)findViewById(R.id.digit5);
        digit6 = (EditText)findViewById(R.id.digit6);

        next_button.setOnClickListener(this);
        resend_button_code.setOnClickListener(this);


        Bundle extras = getIntent().getExtras();
        registered_email = extras.getString("register_email");
        registered_name = extras.getString("my_username");

    }

    @Override
    public void onClick(View v) {

        switch(v.getId()){
            case R.id.next_button:
            {
                //////////////////////////////////////////////////////////////
                inputted_code = digit1.getText().toString()+ digit2.getText().toString()+ digit3.getText().toString()+
                        digit4.getText().toString() + digit5.getText().toString() + digit6.getText().toString();

                RequestQueue queue = Volley.newRequestQueue(this);
                StringRequest example = new StringRequest(Method.GET,
                        "http://" + IP_address + ":3000/admin_verify?name=" + registered_name+  "&verificationcode=" + inputted_code,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                //Toast.makeText(Activity2.this,"Successfully checked Verification Code", Toast.LENGTH_SHORT).show();
                                status = response;
                                if(status.equals("1"))  // successfully entered the verification code
                                {
                                    ///////////////////////////////////////////////////////////////////////////////

                                    RequestQueue queue2 = Volley.newRequestQueue(Activity2.this);
                                    StringRequest example2 = new StringRequest(Method.GET,
                                            "http://" + IP_address + ":3000/admin_verify_updateDB?email=" + registered_email+  "&verificationcode=" + inputted_code,
                                            new Response.Listener<String>() {
                                                @Override
                                                public void onResponse(String response) {
                                                    //Toast.makeText(Activity2.this,"Successfully updated DB", Toast.LENGTH_SHORT).show();
                                                    getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                                                            .putBoolean("isRegistered", true).commit();


                                                    //////////////////// Retreiving the ID and saving it in shared preference
                                                    RequestQueue queue3 = Volley.newRequestQueue(Activity2.this);
                                                    StringRequest example3;
                                                    example3 = new StringRequest(Request.Method.GET, "http://" + IP_address + ":3000/get_AdminID?admin_name=" + registered_name,
                                                            new Response.Listener<String>() {
                                                                @Override
                                                                public void onResponse(String response) {
                                                                    Toast.makeText(Activity2.this,response, Toast.LENGTH_SHORT).show();
                                                                    admin_ID = response;

                                                                    shared = getSharedPreferences("shopAdmin_token", Context.MODE_PRIVATE);
                                                                    final SharedPreferences.Editor editor = shared.edit();

                                                                    editor.putString("token", admin_ID);
                                                                    editor.commit();



                                                                }
                                                            },
                                                            new Response.ErrorListener()
                                                            {
                                                                @Override
                                                                public void onErrorResponse(VolleyError error)
                                                                {

                                                                }
                                                            }
                                                    );

                                                    queue3.add(example3);

                                                    ////////////////////////////////////////////////////////////////////////////////////


                                                    Intent i = new Intent(Activity2.this, Activity3.class);
                                                    startActivity(i);
                                                    finish();
                                                }
                                            },
                                            new Response.ErrorListener()
                                            {
                                                @Override
                                                public void onErrorResponse(VolleyError error)
                                                {
                                                    Toast.makeText(Activity2.this, "Problem in updating DB", Toast.LENGTH_SHORT).show();

                                                }
                                            }
                                    );


                                    queue2.add(example2);
                                    ///////////////////////////////////////////////////////////////////////////////


                                }

                                else
                                {
                                    if(status.equals("0")) {
                                        Toast.makeText(Activity2.this, "You entered a wrong code! Please re-enter!", Toast.LENGTH_SHORT).show();
                                    }
                                }

                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error)
                            {
                                Toast.makeText(Activity2.this, "Unsuccessfully Checked Verification Code", Toast.LENGTH_SHORT).show();

                            }
                        }
                );

                queue.add(example);

                //////////////////////////////////////////////////////////////

            }
            break;


            case R.id.resend_button:
            {
                String verification_code = GenerateRandomString.randomString(6);

                try {

                    String to = registered_email;
                    String subject = "Verification Code";
                    String message = "Thank you for joining our platform, we promise you the best user experience. \n" + "This is the verification code: " + verification_code + "\n" + " Please input it in the app to verify your account.";

                    if(to.isEmpty()){
                        Toast.makeText(Activity2.this, "You must enter a recipient email", Toast.LENGTH_LONG).show();
                    }else if(subject.isEmpty()){
                        Toast.makeText(Activity2.this, "You must enter a Subject", Toast.LENGTH_LONG).show();
                    }else if(message.isEmpty()){
                        Toast.makeText(Activity2.this, "You must enter a message", Toast.LENGTH_LONG).show();
                    }else {
                        //everything is filled out
                        //send email
                        new SimpleMail().sendEmail(to, subject, message);
                    }

                } catch (Exception e) {
                    e.printStackTrace();

                }

            }
        }


    }

}
