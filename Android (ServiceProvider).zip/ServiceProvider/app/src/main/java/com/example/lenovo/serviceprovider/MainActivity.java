package com.example.lenovo.serviceprovider;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;



// Activities 8 and 9 one is showing the products in a shop and the other


public class MainActivity extends AppCompatActivity implements View.OnClickListener{    // ACTIVITY FOR REGISTERING

    Button back;
    Button next;



    EditText username;
    EditText email;
    EditText password;
    EditText confirmpassword;
    EditText mobilenumber;

    String code;

    String IP_address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        IP_address = "10.40.39.125";

        Boolean isRegistered = getSharedPreferences("PREFERENCE", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getBoolean("isRegistered", false);


        if (isRegistered) {
                Toast.makeText(MainActivity.this, "Has logged in before", Toast.LENGTH_LONG)
                        .show();
                startActivity(new Intent(MainActivity.this, Activity3.class));   // Where to move

                finish();
        }


        back = (Button) findViewById(R.id.back);
        next = (Button)findViewById(R.id.next);

        username = (EditText)findViewById(R.id.name_tv);
        email = (EditText)findViewById(R.id.email_tv);
        password = (EditText)findViewById(R.id.password_tv);
        confirmpassword = (EditText)findViewById(R.id.confirmpassword_tv);
        mobilenumber = (EditText)findViewById(R.id.mobilenumber_tv);


        back.setOnClickListener(this);
        next.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back:
            {
                onBackPressed();
            }
            break;

            case R.id.next:
            {
                if(password.getText().toString().equals(confirmpassword.getText().toString()) && !(username.getText().toString().isEmpty()) &&!(email.getText().toString().isEmpty()) &&!(mobilenumber.getText().toString().isEmpty())
                        && !(password.getText().toString().isEmpty()))
                {
                    RequestQueue queue = Volley.newRequestQueue(this);

                    StringRequest example = new StringRequest(Request.Method.GET,
                            "http://" + IP_address + ":3000/admin_signup?name=" + username.getText().toString() + "&email=" + email.getText().toString() +
                                    "&password=" + password.getText().toString() + "&mobilenumber=" + mobilenumber.getText().toString() ,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(MainActivity.this,"NEXT Established", Toast.LENGTH_SHORT).show();
                                    code = response.toString();

                                    Toast.makeText(MainActivity.this, code, Toast.LENGTH_SHORT).show();

                                    try {

                                        String to = email.getText().toString();
                                        String subject = "Verification Code";
                                        String message = "Thank you for joining our platform, we promise you the best business experience. \n" +  "This is the verification code: " + code + "\n" + " Please input it in the app to verify your account.";

                                        if(to.isEmpty()){
                                            Toast.makeText(MainActivity.this, "You must enter a recipient email", Toast.LENGTH_LONG).show();
                                        }else if(subject.isEmpty()){
                                            Toast.makeText(MainActivity.this, "You must enter a Subject", Toast.LENGTH_LONG).show();
                                        }else if(message.isEmpty()){
                                            Toast.makeText(MainActivity.this, "You must enter a message", Toast.LENGTH_LONG).show();
                                        }else {
                                            //everything is filled out
                                            //send email
                                            new SimpleMail().sendEmail(to, subject, message);
                                        }

                                    } catch (Exception e) {
                                        e.printStackTrace();

                                    }


                                    ////////////////////////////////////////////////////
                                    Intent i = new Intent(MainActivity.this, Activity2.class);  // move to verify screen
                                    i.putExtra("register_email", email.getText().toString());   // pass the inputted email
                                    i.putExtra("my_username", username.getText().toString());
                                    startActivity(i);
                                   // finish();

                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(MainActivity.this, "Connection error. Try Again Later", Toast.LENGTH_SHORT).show();
                                }

                            }
                    );

                    queue.add(example);
                }

                else{
                    Toast.makeText(MainActivity.this, "Wrong or missing Entries!", Toast.LENGTH_SHORT).show();
                }

            }
            break;
        }
    }
}


