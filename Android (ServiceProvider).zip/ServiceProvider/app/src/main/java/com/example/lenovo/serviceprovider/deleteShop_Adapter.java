package com.example.lenovo.serviceprovider;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static android.content.Context.MODE_PRIVATE;

public class deleteShop_Adapter extends ArrayAdapter<Item>
{
    List<Item> my_list;
    ArrayList<Item> my_arraylist;
    Context mContext;

    String IP_address = "10.40.39.125";

    String shopName;
    String admin_ID;


    public deleteShop_Adapter(Context context, List<Item> my_list) {
        super(context,R.layout.list_delete_item, my_list);
        this.my_list = my_list;
        this.my_arraylist = new ArrayList<Item>();
        this.my_arraylist.addAll(my_list);
        this.mContext= context;

    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        if (convertView == null)
            convertView = LayoutInflater.
                    from(getContext()).
                    inflate(
                            R.layout.list_delete_item,
                            parent,
                            false
                    );



        ImageView profile_pic = (ImageView)convertView.findViewById(R.id.profile_pic2);
        TextView shop_name = (TextView)convertView.findViewById(R.id.shopName2);
        TextView address = (TextView)convertView.findViewById(R.id.address2);
        TextView phone_no = (TextView)convertView.findViewById(R.id.number2);
        TextView orders = (TextView)convertView.findViewById(R.id.price2);
        RatingBar rating = (RatingBar)convertView.findViewById(R.id.rating2);


        Item item = getItem(position);  // the item should be sent here filled from the APIs


        if(item.image_url != null && !item.image_url .isEmpty())
           Picasso.with(getContext()).load(item.image_url).fit().centerInside().into(profile_pic);
        shop_name.setText(item.shop_name);
        address.setText(item.address);
        phone_no.setText(item.landline);
        orders.setText(item.no_orders);

        shopName = item.shop_name;


        if(item.rating .equals("0") )
            rating.setRating(0);   // to convert the rating to a number }

        else {
            if (item.rating.equals("1"))
                rating.setRating(1);

            else {
                if(item.rating.equals("2"))
                    rating.setRating(2);

                else {
                    if(item.rating.equals("3"))
                        rating.setRating(3);

                    else {
                        if (item.rating.equals("4"))
                            rating.setRating(4);

                        else
                        if(item.rating.equals("5"))
                            rating.setRating(5);

                    }
                }
            }


        }


        ////////////////////////
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                admin_ID =  mContext.getSharedPreferences("shopAdmin_token", MODE_PRIVATE)
                        .getString("token", "hana");



                RequestQueue queue3 = Volley.newRequestQueue(mContext);
                StringRequest example3;
                example3 = new StringRequest(Request.Method.GET, "http://" + IP_address + ":3000/delete_shop?shop_name=" + shopName
                        + "&shopAdmin_ID=" + admin_ID,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Toast.makeText(mContext,"Successfully deleted the shop", Toast.LENGTH_SHORT).show();

                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error)
                            {
                                Toast.makeText(mContext,"Problem deleteing the shop. Try Again!", Toast.LENGTH_SHORT).show();

                            }
                        }
                );

                queue3.add(example3);


                my_arraylist.remove(position);
                notifyDataSetChanged();




                /// Need to delete any clickable entry
            }
        });

        ////////////////////////

        return convertView;
    }

}
