package com.example.lenovo.serviceprovider;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.List;

public class Activity_ADDCategory extends AppCompatActivity implements View.OnClickListener{

    Spinner cat_tv;
    List<String> cats = new ArrayList<String>();

    String IP_address = "10.40.39.125";

    String shopName;

    Button next;
    Integer counter=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__addcategory);

        cat_tv = (Spinner) findViewById(R.id.dropdown);

        next = (Button)findViewById(R.id.cat_next);
        next.setOnClickListener(this);

        cats.add("Food");
        cats.add("Clothes");
        cats.add("Accessories");
        cats.add("Beauty Products");

        Bundle extras = getIntent().getExtras();
        shopName = extras.getString("shopname");

        addItemsOnSpinner1();
        addListenerOnSpinnerItemSelection();

    }


    public void addItemsOnSpinner1() {

        cat_tv = (Spinner) findViewById(R.id.dropdown);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, cats);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cat_tv.setAdapter(dataAdapter);
    }

    public void addListenerOnSpinnerItemSelection() {
        cat_tv = (Spinner) findViewById(R.id.dropdown);

        cat_tv.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                if(counter!=0)
                {
                    RequestQueue queue = Volley.newRequestQueue(Activity_ADDCategory.this);
                    StringRequest example = new StringRequest(Request.Method.GET,
                            "http://" + IP_address + ":3000/add_shop_category?category_id=" + String.valueOf(position+1) + "&shop_name=" + shopName,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(Activity_ADDCategory.this,"Successful Added shop category", Toast.LENGTH_SHORT).show();


                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error)
                                {
                                    Toast.makeText(Activity_ADDCategory.this, "Unsuccessful Shop Category Adding", Toast.LENGTH_SHORT).show();

                                }
                            }
                    );

                    queue.add(example);
                }
                counter++;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }
        });
    }


    @Override
    public void onClick(View v) {

        // When he clicks next go back to the activity of viewing all shops
        Intent i = new Intent(Activity_ADDCategory.this, Activity5.class);
        startActivity(i);

    }
}
