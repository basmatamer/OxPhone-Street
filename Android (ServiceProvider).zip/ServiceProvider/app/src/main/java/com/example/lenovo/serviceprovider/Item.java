package com.example.lenovo.serviceprovider;

public class Item {
    String shop_name;
    String image_url;
    String landline;
    String address;
    String no_orders;
    String rating;
}
