package com.example.lenovo.serviceprovider;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static android.content.Context.MODE_PRIVATE;

public class My_Adapter extends ArrayAdapter<Item> {

    List<Item> my_list;
    ArrayList<Item> my_arraylist;
    Context mContext;

    int my_rate;
    String cat;

    String IP_address = "10.40.39.125";
    String shopAdmin_ID;

    Intent i;
    Activity act;

    public My_Adapter(Context context, List<Item> my_list, Activity m) {
        super(context,R.layout.list_item, my_list);
        this.my_list = my_list;
        this.my_arraylist = new ArrayList<Item>();
        this.my_arraylist.addAll(my_list);
        this.mContext= context;
        this.act = m;

    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {

        if (convertView == null)
            convertView = LayoutInflater.
                    from(getContext()).
                    inflate(
                            R.layout.list_item,
                            parent,
                            false
                    );



        ImageView profile_pic = (ImageView)convertView.findViewById(R.id.profile_pic);
        TextView shop_name = (TextView)convertView.findViewById(R.id.shopName);
        TextView address = (TextView)convertView.findViewById(R.id.address);
        TextView phone_no = (TextView)convertView.findViewById(R.id.number);
        TextView orders = (TextView)convertView.findViewById(R.id.price);
        RatingBar rating = (RatingBar)convertView.findViewById(R.id.rating);



        Item item = getItem(position);  // the item should be sent here filled from the APIs

        ///////////////////////////

        //////////////////////////////////////

        if(item.image_url != null && !item.image_url .isEmpty())
            Picasso.with(getContext()).load(item.image_url).fit().centerInside().into(profile_pic);

        shop_name.setText(item.shop_name);
        address.setText(item.address);
        phone_no.setText(item.landline);
        orders.setText(item.no_orders);



        if(item.rating .equals("0") )
            rating.setRating(0);   // to convert the rating to a number }

        else {
            if (item.rating.equals("1"))
                rating.setRating(1);

            else {
                if(item.rating.equals("2"))
                    rating.setRating(2);

                else {
                if(item.rating.equals("3"))
                    rating.setRating(3);

                else {
                    if (item.rating.equals("4"))
                        rating.setRating(4);

                    else
                        if(item.rating.equals("5"))
                            rating.setRating(5);

                }
                }
            }


        }


       // rating.setRating(3);

                ////////////////////////
                convertView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        i = new Intent(mContext, Activity6.class);   // to see a list of products there

                        final Item item = getItem(position);

                        //act.getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                        ///////////////// Call API to get the category of this product
                        shopAdmin_ID = mContext.getSharedPreferences("shopAdmin_token", MODE_PRIVATE)
                                .getString("token", "hana");

                        RequestQueue queue3 = Volley.newRequestQueue(mContext);
                                    StringRequest example3 = new StringRequest(Request.Method.GET,
                                            "http://" + IP_address + ":3000/get_shop_category?shop_name=" + item.shop_name +
                                                    "&shopAdmin_ID=" + shopAdmin_ID,
                                            new Response.Listener<String>() {
                                                @Override
                                                public void onResponse(String response) {
                                                    Toast.makeText(mContext,"Successfully retreived shop category id", Toast.LENGTH_SHORT).show();
                                                    Toast.makeText(mContext,response, Toast.LENGTH_SHORT).show();

                                                    cat = response;
                                                    i.putExtra("category", cat);
                                                    i.putExtra("shopName", item.shop_name);
                                                    mContext.startActivity(i);
                                                    //act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                                                }
                                            },
                                            new Response.ErrorListener()
                                            {
                                                @Override
                                                public void onErrorResponse(VolleyError error)
                                                {
                                                    Toast.makeText(mContext, "Problem in retreiving shop category name", Toast.LENGTH_SHORT).show();

                                                }
                                            }
                                    );


                                    queue3.add(example3);


                        //////////////////////////////////////////////////////

                    }
                });

        ////////////////////////

        return convertView;
    }

    
}
