package com.example.lenovo.serviceprovider;      // To check Orders


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Activity9 extends AppCompatActivity {

    String admin_ID;
    JSONObject obj;
    private ArrayList<String> m = new ArrayList<>();

    ListView mlistview;
    Orders_Adapter adapter;
    String temp, name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_9);

        admin_ID = getSharedPreferences("shopAdmin_token", MODE_PRIVATE)
                .getString("token", "hana");
        /////////// call api

        ////////////////////////////////////////////////////////

        RequestQueue queue = Volley.newRequestQueue(Activity9.this);
        JSONArray jsonAr = new JSONArray();
        String gurl = "http://10.40.39.125:3000/get_admin_products?shopAdmin_ID=" + admin_ID;

        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, gurl, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity9.this, "Connected to The Products API", Toast.LENGTH_SHORT).show();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                temp = obj.getString("cart_p_id");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            get_product_name(temp);
                            //m.add(temp);

                        }


                    }
                },

                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Activity9.this, "Failed to connect to Products API.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        queue.add(jsonArRequest);







        ////////////////////////
    }

    private void get_product_name(String p_id)
    {
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest example = new StringRequest(Request.Method.GET,
                "http://10.40.39.125:3000/get_products_name_from_ID?product_ID=" + p_id,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(Activity9.this,"Successful Product Name Retreival", Toast.LENGTH_SHORT).show();
                        ///////////////////
                        name = response;
                        m.add(name);
                        mlistview = (ListView) findViewById(R.id.my_listview3);

                        ArrayList<String> list = new ArrayList<String>(m);

                        adapter = new Orders_Adapter(Activity9.this, list);
                        mlistview.setAdapter(adapter);

                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Toast.makeText(Activity9.this, "Unsuccessful Product Name Retreival", Toast.LENGTH_SHORT).show();

                    }
                }
        );

        queue.add(example);

    }

}

//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//import android.util.Log;
//import android.widget.ListView;
//import android.widget.Toast;
//
//import com.android.volley.Request;
//import com.android.volley.RequestQueue;
//import com.android.volley.Response;
//import com.android.volley.VolleyError;
//import com.android.volley.toolbox.JsonArrayRequest;
//import com.android.volley.toolbox.StringRequest;
//import com.android.volley.toolbox.Volley;
//import com.squareup.picasso.Picasso;
//
//import org.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
//
//import java.util.ArrayList;
//
//public class Activity9 extends AppCompatActivity {
//
//    String admin_ID;
//
//    JSONObject obj;
//    JSONObject obj3;
//
//    Boolean p_flag = false;
//    Boolean s_flag = false;
//    //Boolean c_flag = false;
//
//    private ArrayList<Order> m = new ArrayList<>();
//
//    ListView mlistview;
//    Orders_Adapter adapter;
//    String temp, temp3;
//
//    Order my_order;
//
//    String IP_address = "10.40.39.125";
//
//    String customer_name;
//
//    String internal_customer_name;
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_9);
//
//        admin_ID = getSharedPreferences("shopAdmin_token", MODE_PRIVATE)
//                .getString("token", "hana");
//        /////////// call api
//
//        ////////////////////////////////////////////////////////
//
//        RequestQueue queue = Volley.newRequestQueue(Activity9.this);
//        JSONArray jsonAr = new JSONArray();
//        String gurl = "http://" + IP_address + ":3000/get_admin_products?shopAdmin_ID=" + admin_ID;    // returns an array , we need product IDs from it
//
//        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, gurl, jsonAr,
//                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
//                {
//                    @Override
//                    public void onResponse(JSONArray response) {
//                        Toast.makeText(Activity9.this, "Connected to The Products API", Toast.LENGTH_SHORT).show();
//                        for (int i = 0; i < response.length(); i++) {    // all product IDs
//                            try {
//                                my_order = new Order();
//                                obj = new JSONObject();
//                                try {
//                                    obj = response.getJSONObject(i);
//                                } catch (JSONException e) {
//                                    e.printStackTrace();
//                                }
//                                temp = obj.getString("cart_p_id");
//
//
//                            } catch (JSONException e) {
//                                e.printStackTrace();
//                            }
//                            get_order_details(temp);    // pass each ID one by one
//                        }
//
//                        mlistview = (ListView) findViewById(R.id.my_listview3);
//
//                        ArrayList<Order> list = new ArrayList<Order>(m);
//
//                        adapter = new Orders_Adapter(Activity9.this, list);
//                        mlistview.setAdapter(adapter);
//
//
//                    }
//                },
//
//                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
//                {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(Activity9.this, "Failed to connect to Products API.", Toast.LENGTH_SHORT).show();
//                    }
//                }
//        );
//        queue.add(jsonArRequest);
//
//
//        ////////////////////////
//    }
//
//    private void get_order_details(String p_id) {
//        p_flag = false;
//        s_flag = false;
//        //c_flag = false;
//
//        // each of the following API fill a field in object Order
//
//        RequestQueue queue = Volley.newRequestQueue(this);
//        StringRequest example = new StringRequest(Request.Method.GET,
//                "http://" + IP_address + ":3000/get_products_name_from_ID?product_ID=" + p_id,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        Toast.makeText(Activity9.this, "Successful Product Name Retreival", Toast.LENGTH_SHORT).show();
//                        ///////////////////
//                        my_order.product_name = response;
//                        p_flag = true;
//
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(Activity9.this, "Unsuccessful Product Name Retreival", Toast.LENGTH_SHORT).show();
//
//                    }
//                }
//        );
//
//        queue.add(example);
//
//        ////////////////////////////////////////////
//
//        RequestQueue queue2 = Volley.newRequestQueue(Activity9.this);     // gets the shop name of this product
//        StringRequest example2 = new StringRequest(Request.Method.GET,
//                "http://" + IP_address + ":3000/order_get_shop_name?cart_p_id=" + p_id,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        Toast.makeText(Activity9.this, "Successful retrieved shop name", Toast.LENGTH_SHORT).show();
//                        ///////////////////
//                        my_order.shop_name = response;
//                        s_flag = true;
//
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(Activity9.this, "Unsuccessful shop name Retreival", Toast.LENGTH_SHORT).show();
//
//                    }
//                }
//        );
//
//        queue2.add(example2);
//
//
//        if (s_flag == true && p_flag == true) {
//            m.add(my_order);   // the 1st entry in the ListView
//        }
//
//    }
//
//}
//
//        ////////////////////////////////////////////////
////
////        RequestQueue queue3 = Volley.newRequestQueue(Activity9.this);    // return an array of customer IDs
////        JSONArray jsonAr3 = new JSONArray();
////        String gurl3 = "http://" + IP_address + ":3000/get_admin_customers?shopAdmin_ID=" + admin_ID + "&cart_p_id=" + p_id;
////
////        JsonArrayRequest jsonArRequest3 = new JsonArrayRequest(Request.Method.GET, gurl3, jsonAr3,
////                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
////                {
////                    @Override
////                    public void onResponse(JSONArray response) {
////                        c_flag = true;
////                        Toast.makeText(Activity9.this, "Connected to customers who ordered", Toast.LENGTH_SHORT).show();
////                        for (int i = 0; i < response.length(); i++) {    // all product IDs
////                            try {
////                                obj3 = new JSONObject();
////                                try {
////                                    obj3 = response.getJSONObject(i);
////                                } catch (JSONException e) {
////                                    e.printStackTrace();
////                                }
////                                temp3 = obj.getString("cart_cu_id");
////
////                                    Log.v("hababaya", temp3);
////                            } catch (JSONException e) {
////                                e.printStackTrace();
////                            }
////                            get_customers_names(temp3);
////
////
////                        }    // It'll keep going in this loop until it fills my_order object with all customer names
////
////
////                    }
////                },
////
////                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
////                {
////                    @Override
////                    public void onErrorResponse(VolleyError error) {
////                        Toast.makeText(Activity9.this, "Failed to connect to customers who ordered.", Toast.LENGTH_SHORT).show();
////                    }
////                }
////        );
////        queue3.add(jsonArRequest3);
//
//        ///////////////////////////////////////////////
//
//
//
//
//
//
////    private void get_customers_names(String cu_id) {
////
////        RequestQueue queue2 = Volley.newRequestQueue(Activity9.this);
////        Log.v("gazaraya", cu_id);
////        StringRequest example2 = new StringRequest(Request.Method.GET,
////                "http://" + IP_address + ":3000/get_customer_name_from_ID?customer_ID=" +cu_id,
////                new Response.Listener<String>() {
////                    @Override
////                    public void onResponse(String response) {
////                        Toast.makeText(Activity9.this,"Successful retrieved customer's name", Toast.LENGTH_SHORT).show();
////                        ///////////////////
////                        internal_customer_name = response;
////                        my_order.customer_name.add(internal_customer_name);
////                        if(c_flag == true && s_flag == true && p_flag == true)
////                        {
////                            m.add(my_order);   // the 1st entry in the ListView
////
////
////                        }
////                    }
////                },
////                new Response.ErrorListener()
////                {
////                    @Override
////                    public void onErrorResponse(VolleyError error)
////                    {
////                        Toast.makeText(Activity9.this, "Unsuccessful customer name Retreival", Toast.LENGTH_SHORT).show();
////
////                    }
////                }
////        );
////
////        queue2.add(example2);
////
////
////    }
////    //
//
//
