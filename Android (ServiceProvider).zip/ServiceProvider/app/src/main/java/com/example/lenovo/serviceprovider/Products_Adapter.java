package com.example.lenovo.serviceprovider;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class Products_Adapter extends ArrayAdapter<ProductDetails> {
    List<ProductDetails> my_list;
    ArrayList<ProductDetails> my_arraylist;
    Context mContext;

    String IP_address = "10.40.39.125";


    Activity act;

    String cat, product_shopname;

    String admin_ID;

    public Products_Adapter(Context context, List<ProductDetails> my_list, Activity m) {
        super(context,R.layout.product_list_item, my_list);
        this.my_list = my_list;
        this.my_arraylist = new ArrayList<ProductDetails>();
        this.my_arraylist.addAll(my_list);
        this.mContext= context;

        this.act = m;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        if (convertView == null)
            convertView = LayoutInflater.
                    from(getContext()).
                    inflate(
                            R.layout.product_list_item,
                            parent,
                            false
                    );



        ImageView profile_pic = (ImageView)convertView.findViewById(R.id.profile_pic);
        final TextView shop_name = (TextView)convertView.findViewById(R.id.shopName);
        TextView orders = (TextView)convertView.findViewById(R.id.price);
        RatingBar rating = (RatingBar)convertView.findViewById(R.id.rating);



        ProductDetails product = getItem(position);  // the item should be sent here filled from the APIs

        ///////////////////////////

        //////////////////////////////////////


        Picasso.with(getContext()).load(product.image_url).fit().centerInside().into(profile_pic);
        shop_name.setText(product.name);

        orders.setText(product.no_stock);



        if(product.rating .equals("0") )
            rating.setRating(0);   // to convert the rating to a number }

        else {
            if (product.rating.equals("1"))
                rating.setRating(1);

            else {
                if(product.rating.equals("2"))
                    rating.setRating(2);

                else {
                    if(product.rating.equals("3"))
                        rating.setRating(3);

                    else {
                        if (product.rating.equals("4"))
                            rating.setRating(4);

                        else
                        if(product.rating.equals("5"))
                            rating.setRating(5);

                    }
                }
            }


        }


        // rating.setRating(3);

        ////////////////////////
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                act.getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

                ProductDetails chosen_product = my_list.get(position);

                RequestQueue queue3 = Volley.newRequestQueue(mContext);
                StringRequest example3;
                example3 = new StringRequest(Request.Method.GET, "http://" + IP_address + ":3000/delete_product?product_name="
                        + chosen_product.name ,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Toast.makeText(mContext,"Successfully deleted the product", Toast.LENGTH_SHORT).show();

                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error)
                            {
                                Toast.makeText(mContext,"Problem deleteing the product. Try Again!", Toast.LENGTH_SHORT).show();

                            }
                        }
                );

                queue3.add(example3);



                RequestQueue queue2 = Volley.newRequestQueue(mContext);
                StringRequest example2 = new StringRequest(Request.Method.GET,
                        "http://" + IP_address + ":3000/get_product_category?name=" + chosen_product.name + "&color=" + chosen_product.color+
                                "&size=" + chosen_product.size,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Toast.makeText(mContext,"Successfully retreived product category id", Toast.LENGTH_SHORT).show();

                                cat = response;


                                act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error)
                            {
                                Toast.makeText(mContext, "Problem in retreiving product category name", Toast.LENGTH_SHORT).show();

                            }
                        }
                );


                queue2.add(example2);

                RequestQueue queue1 = Volley.newRequestQueue(mContext);
                StringRequest example1 = new StringRequest(Request.Method.GET,
                        "http://" + IP_address + ":3000/get_shopName_from_product_name?name=" + chosen_product.name + "&color=" + chosen_product.color+
                                "&size=" + chosen_product.size,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Toast.makeText(mContext,"Successfully retreived product shop name", Toast.LENGTH_SHORT).show();

                                product_shopname = response;


                                act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error)
                            {
                                Toast.makeText(mContext, "Problem in retreiving product shop name", Toast.LENGTH_SHORT).show();

                            }
                        }
                );


                queue1.add(example1);


                my_arraylist.remove(position);
                notifyDataSetChanged();

                Intent I =  new Intent(mContext, Activity6.class);
                I.putExtra("shopName", product_shopname);
                I.putExtra("category", cat);
                mContext.startActivity(I);
            }
        });

        // order_get_shop_name

        ////////////////////////

        return convertView;
    }







}
