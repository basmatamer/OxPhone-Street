package com.example.lenovo.serviceprovider;    // responsible for adding a new shop

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Binder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

public class Activity4 extends AppCompatActivity implements View.OnClickListener{

    TextView toolbar_title;

    Button back;
    Button save;
    Button upload;
    Button back_toolbar_button;

    Boolean is_upload = false;
    String image_url;

    ImageView dp;

    EditText shopname;

    // these 2 are optional so won't assert that the user should input them
    // aw n2olo input NULL
    EditText address;
    EditText landline;

    SharedPreferences shared;
    String admin_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_4);

        dp = (ImageView) findViewById(R.id.dp);

        shopname = (EditText) findViewById(R.id.shop_name_tv);
        address = (EditText) findViewById(R.id.address_tv);
        landline = (EditText)findViewById(R.id.landline_tv);

        toolbar_title = (TextView)findViewById(R.id.toolbar_textView);
        toolbar_title.setText("Add new Shop");

        back = (Button)findViewById(R.id.back);
        save = (Button)findViewById(R.id.save);
        upload = (Button)findViewById(R.id.upload);
        back_toolbar_button = (Button)findViewById(R.id.back_toolbar_button);

        back.setOnClickListener(this);
        save.setOnClickListener(this);
        upload.setOnClickListener(this);
        back_toolbar_button.setOnClickListener(this);

        admin_ID = getSharedPreferences("shopAdmin_token", MODE_PRIVATE)
                .getString("token", "hana");


    }

    @Override
    public void onClick(View v) {

        switch (v.getId())
        {
            case R.id.back:
                onBackPressed();
            break;

            case R.id.back_toolbar_button:
                onBackPressed();
            break;

            case R.id.save:
            {
                if(!(shopname.getText().toString().isEmpty()) &&!(landline.getText().toString().isEmpty()) &&!(address.getText().toString().isEmpty()))
                {
                    // Need to add to Database

                    RequestQueue queue = Volley.newRequestQueue(this);
                    StringRequest example = new StringRequest(Request.Method.GET,
                            "http://10.40.39.125:3000/add_shop?name=" + shopname.getText().toString() + "&landline=" + landline.getText().toString()
                            + "&address=" + address.getText().toString() + "&adminID=" + admin_ID,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(Activity4.this,"Successfully Added a new shop", Toast.LENGTH_SHORT).show();

                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error)
                                {
                                    Toast.makeText(Activity4.this, "Problem Adding a new shop", Toast.LENGTH_SHORT).show();

                                }
                            }
                    );

                    queue.add(example);

                }

                else
                {
                    Toast.makeText(Activity4.this, "Invalid or empty fields! Please Try Again!", Toast.LENGTH_LONG).show();
                }

                if(is_upload == true){   // an image was uploaded, so will save it to DB

                    RequestQueue queue2 = Volley.newRequestQueue(Activity4.this);
                    StringRequest example2 = new StringRequest(Request.Method.GET,
                            "http://10.40.39.125:3000/update_shop_image?url=" + image_url + "&name=" + shopname.getText().toString(),
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(Activity4.this,"Successfully updated image url to DB", Toast.LENGTH_SHORT).show();

                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error)
                                {
                                    Toast.makeText(Activity4.this, "Problem in updating DB", Toast.LENGTH_SHORT).show();

                                }
                            }
                    );


                    queue2.add(example2);
                }
                ////////////////////////////////////////

            }
            break;

            case R.id.upload:
            {
                RequestQueue queue = Volley.newRequestQueue(this);

               StringRequest example = new StringRequest(Request.Method.GET,
                        "http://10.40.39.125:3000/uploadImage?path=" + "E:/Summer 2018/basma.jpg",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Toast.makeText(Activity4.this,"Successful Upload", Toast.LENGTH_SHORT).show();
                                image_url = response;

                                Toast.makeText(Activity4.this, image_url, Toast.LENGTH_SHORT).show();
                                is_upload = true;

                                ///////////////////

                                Picasso.with(Activity4.this).load(image_url).fit().centerInside().into(dp);

                                ///////////////////

                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error)
                            {
                                Toast.makeText(Activity4.this, "Unsuccessful Upload", Toast.LENGTH_SHORT).show();

                            }
                        }
                );

                queue.add(example);

            }
            break;
        }

    }
}
