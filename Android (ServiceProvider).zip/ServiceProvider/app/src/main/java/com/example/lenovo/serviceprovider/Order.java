package com.example.lenovo.serviceprovider;

import java.util.ArrayList;

public class Order {
    // ArrayList<String> customer_name = new ArrayList<>();
    String product_name;
    String shop_name;
}
