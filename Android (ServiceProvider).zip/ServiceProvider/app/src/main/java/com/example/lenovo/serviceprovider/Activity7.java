package com.example.lenovo.serviceprovider;    // The details of each ListItem  (IGNORE FOR NOWW)

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


// Need to handle deleting an item upon clicking on a List Item


public class Activity7 extends AppCompatActivity implements View.OnClickListener{

    Button add_item;

    String IP_address = "10.40.39.125";

    String admin_ID;
    private ArrayList<Item> mEntries;

    Item item;
    JSONObject obj;

    ListView mlistview;
    deleteShop_Adapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_7);

        add_item = (Button)findViewById(R.id.add_button);

        add_item.setOnClickListener(this);


        admin_ID = getSharedPreferences("shopAdmin_token", MODE_PRIVATE)
                .getString("token", "hana");

        mEntries = new ArrayList<Item>();
        ////////////////////////////////////////////////////////

        RequestQueue queue = Volley.newRequestQueue(Activity7.this);
        JSONArray jsonAr = new JSONArray();
        String gurl = "http://" + IP_address + ":3000/get_shops_details?adminID=" + admin_ID;

        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, gurl, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity7.this, "Connected to The shops API", Toast.LENGTH_SHORT).show();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                item = new Item();
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                item.shop_name= obj.getString("name");
                                item.rating = obj.getString("rating");
                                item.no_orders = obj.getString("no_orders");
                                item.landline = obj.getString("landline");
                                item.address = obj.getString("address");
                                item.image_url = obj.getString("image_url");



                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            mEntries.add(item);

                        }

                        mlistview = (ListView) findViewById(R.id.my_listview2);

                        ArrayList<Item> list = new ArrayList<Item>(mEntries);

                        adapter = new deleteShop_Adapter(Activity7.this, list);
                        mlistview.setAdapter(adapter);
                    }
                },

                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Activity7.this, "Failed to connect to Shops API.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        queue.add(jsonArRequest);



        //////////////////////////////////////////////////////////

        /////// Adapter things
    }

    @Override
    public void onClick(View v) {
        // add a new shop so direct him to new activity
        switch (v.getId())
        {
            case R.id.add_button:
            {
                Intent i = new Intent(Activity7.this, Activity_ADDShop.class);
                startActivity(i);
            }
            break;
        }

    }
}
