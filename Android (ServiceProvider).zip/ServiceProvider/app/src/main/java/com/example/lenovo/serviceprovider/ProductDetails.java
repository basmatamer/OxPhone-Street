package com.example.lenovo.serviceprovider;

public class ProductDetails
{
    String name;
    String price;
    String rating;
    String availability;
    String no_stock;
    String color;
    String size;
    String description;
    String image_url;
}
