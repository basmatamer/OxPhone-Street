package com.example.lenovo.serviceprovider;      // lists products in this shop

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Activity6 extends AppCompatActivity implements View.OnClickListener{

    Button add_item;

    String shop_name;
    String cat_id;

    ListView mlistview;
    Products_Adapter adapter;

    ProductDetails product;
    JSONObject obj;
    private ArrayList<ProductDetails> mProducts;

    String IP_address = "10.40.39.125";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_6);

        add_item = (Button)findViewById(R.id.add_button);


        add_item.setOnClickListener(this);

        Bundle extras = getIntent().getExtras();
        shop_name = extras.getString("shopName");
        cat_id = extras.getString("category");




        //////////////////////////////// CALLING API

        mProducts = new ArrayList<ProductDetails>();
        ////////////////////////////////////////////////////////

        RequestQueue queue = Volley.newRequestQueue(Activity6.this);
        JSONArray jsonAr = new JSONArray();
        String gurl = "http://" + IP_address + ":3000/get_products_details?shop_name=" + shop_name;

        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, gurl, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity6.this, "Connected to The Products API", Toast.LENGTH_SHORT).show();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                product = new ProductDetails();
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                product.name= obj.getString("name");
                                product.rating = obj.getString("rating");
                                product.no_stock = obj.getString("numberinstock");
                                product.color = obj.getString("color");
                                product.availability = obj.getString("availability");
                                product.description = obj.getString("description");
                                product.price = obj.getString("price");
                                product.size = obj.getString("size");
                                product.image_url = obj.getString("image_url");



                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            mProducts.add(product);

                        }

                        mlistview = (ListView) findViewById(R.id.my_listview2);

                        ArrayList<ProductDetails> list = new ArrayList<ProductDetails>(mProducts);

                        adapter = new Products_Adapter(Activity6.this, list, Activity6.this);
                        mlistview.setAdapter(adapter);
                    }
                },

                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Activity6.this, "Failed to connect to Products API.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        queue.add(jsonArRequest);




        /////////////////////////////////

    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.add_button:   // to add a new product in the shop
            {
                Intent i = new Intent(Activity6.this, Activity8.class);   // to get the details of the new product
                i.putExtra("shopName", shop_name);
                i.putExtra("category", cat_id);
                startActivity(i);
            }
            break;



        }

    }
}
