package com.example.lenovo.serviceprovider;     // To add a new Product

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.File;
import java.io.IOException;

public class Activity8 extends AppCompatActivity implements View.OnClickListener{

    TextView toolbar_title;
    EditText item_name;
    EditText price;
    EditText color;
    EditText no_stock;
    EditText size;
    EditText description;

    Button save;
    Button back;
    Button upload_image;


    String image_url;
    String IP_address = "10.40.39.125";

    private static final String IMAGE_DIRECTORY = "/Camera";
    private int GALLERY = 1, CAMERA = 2;

    String shop_name;
    String cat_id;

    Boolean is_upload = false;

    ImageView dp;

    String p_id;

    String cat_name;

    Button bar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_8);

        toolbar_title = (TextView)findViewById(R.id.toolbar_textView);
        toolbar_title.setText("Add Product");


        Bundle extras = getIntent().getExtras();
        shop_name = extras.getString("shopName");
        cat_id = extras.getString("category");


        bar = (Button)findViewById(R.id.back_toolbar_button);

        dp = (ImageView)findViewById(R.id.dp);

        upload_image = (Button) findViewById(R.id.upload);

        item_name = (EditText)findViewById(R.id.shop_name_tv);
        price = (EditText)findViewById(R.id.address_tv);
        color = (EditText)findViewById(R.id.landline_tv);
        no_stock = (EditText)findViewById(R.id.no_in_stock_tv);
        size = (EditText)findViewById(R.id.size_tv);
        description = (EditText)findViewById(R.id.description_tv);


        back = (Button)findViewById(R.id.back);
        save = (Button)findViewById(R.id.save);


        bar.setOnClickListener(this);
        save.setOnClickListener(this);
        back.setOnClickListener(this);
        upload_image.setOnClickListener(this);

        switch (Integer.valueOf(cat_id))
        {
            case 1:
                cat_name = "Food";
                break;

            case 2:
                cat_name = "Clothes";
                break;

            case 3:
                cat_name = "Accessories";
                break;

            case 4:
                cat_name = "Beauty Products";
                break;

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.save:
            {
                if(!(item_name.getText().toString().isEmpty()) &&!(price.getText().toString().isEmpty()) &&!(color.getText().toString().isEmpty())
                        && !(no_stock.getText().toString().isEmpty()) &&!(size.getText().toString().isEmpty()) &&!(description.getText().toString().isEmpty()))
                {

                    RequestQueue queue = Volley.newRequestQueue(this);

                    StringRequest example = new StringRequest(Request.Method.GET,
                            "http://" + IP_address + ":3000/add_newproduct?name=" + item_name.getText().toString() + "&price=" + price.getText().toString()
                                    +"&availability=" + "Y" + "&numberinstock=" + no_stock.getText().toString() + "&color=" + color.getText().toString() + "&size=" + size.getText().toString()+
                                    "&description=" + description.getText().toString() + "&category_name=" + cat_name + "&shop_name=" + shop_name,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(Activity8.this, "NEXT Established", Toast.LENGTH_SHORT).show();

                                    ////////////////////////////////////////////////////
                                    RequestQueue queue1 = Volley.newRequestQueue(Activity8.this);
                                    StringRequest example1 = new StringRequest(Request.Method.GET,
                                            "http://" + IP_address + ":3000/retreive_p_id?name=" + item_name.getText().toString() + "&color=" + color.getText().toString() + "&size=" + size.getText().toString(),
                                            new Response.Listener<String>() {
                                                @Override
                                                public void onResponse(String response) {
                                                    Toast.makeText(Activity8.this,"Successfully retrieved product ID", Toast.LENGTH_SHORT).show();
                                                    p_id = response;
                                                    //////////////////////////////

                                                    if(is_upload == true){   // an image was uploaded, so will save it to DB

                                                        RequestQueue queue = Volley.newRequestQueue(Activity8.this);

                                                        StringRequest example = new StringRequest(Request.Method.GET,
                                                                "http://" + IP_address + ":3000/uploadImage?path=" + "C:/Users/Lenovo/Desktop/ProjectProfiles/bDress.png",
                                                                new Response.Listener<String>() {
                                                                    @Override
                                                                    public void onResponse(String response) {
                                                                        Toast.makeText(Activity8.this,"Successful Upload", Toast.LENGTH_SHORT).show();
                                                                        image_url = response;

                                                                        //////////////////////////////
                                                                        RequestQueue queue2 = Volley.newRequestQueue(Activity8.this);
                                                                        StringRequest example2 = new StringRequest(Request.Method.GET,
                                                                                "http://" + IP_address + ":3000/update_product_image?url=" + image_url + "&p_id=" + p_id,
                                                                                new Response.Listener<String>() {
                                                                                    @Override
                                                                                    public void onResponse(String response) {
                                                                                        Toast.makeText(Activity8.this,"Successfully updated image url to DB", Toast.LENGTH_SHORT).show();

                                                                                    }
                                                                                },
                                                                                new Response.ErrorListener()
                                                                                {
                                                                                    @Override
                                                                                    public void onErrorResponse(VolleyError error)
                                                                                    {
                                                                                        Toast.makeText(Activity8.this, "Problem in updating image in DB", Toast.LENGTH_SHORT).show();

                                                                                    }
                                                                                }
                                                                        );


                                                                        queue2.add(example2);


                                                                    }
                                                                },
                                                                new Response.ErrorListener()
                                                                {
                                                                    @Override
                                                                    public void onErrorResponse(VolleyError error)
                                                                    {
                                                                        Toast.makeText(Activity8.this, "Unsuccessful Upload", Toast.LENGTH_SHORT).show();

                                                                    }
                                                                }
                                                        );

                                                        queue.add(example);


                                                      }
                                                    ///////////////////////////////
                                                }
                                            },
                                            new Response.ErrorListener()
                                            {
                                                @Override
                                                public void onErrorResponse(VolleyError error)
                                                {
                                                    Toast.makeText(Activity8.this, "Problem in retrieving product ID", Toast.LENGTH_SHORT).show();

                                                }
                                            }
                                    );


                                    queue1.add(example1);

                                    //////////////////////////////////////

                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(Activity8.this, "Connection error. Try Again Later", Toast.LENGTH_SHORT).show();
                                }

                            }
                    );

                    queue.add(example);

                }

                else
                {
                    Toast.makeText(Activity8.this, "PLease enter empty fields!", Toast.LENGTH_SHORT).show();
                }


                Intent I =  new Intent(Activity8.this, Activity6.class);
                I.putExtra("shopName", shop_name);
                I.putExtra("category", cat_id );
                startActivity(I);


            }
            break;

            case R.id.back:
            {
                onBackPressed();
            }
            break;

            case R.id.upload:
            {

                /////////////////////////////////////////////////////////////

                is_upload = true;
                // showPictureDialog();

                if (ContextCompat.checkSelfPermission(Activity8.this, Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_DENIED)
                    ActivityCompat.requestPermissions(Activity8.this, new String[] {Manifest.permission.CAMERA}, 10);


                choosePhotoFromGallery();

            }
            break;

            case R.id.back_toolbar_button:
                onBackPressed();
            break;

        }

    }

    public void choosePhotoFromGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(galleryIntent, GALLERY);
    }

    private void takePhotoFromCamera() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                Uri contentURI = data.getData();

                File my_file = new File(getRealPathFromURI(contentURI));



                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), contentURI);
                    dp.setImageBitmap(bitmap);

                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(Activity8.this, "Failed!", Toast.LENGTH_SHORT).show();
                }
            }

        } else if (requestCode == CAMERA) {
            Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
            dp.setImageBitmap(thumbnail);


        }

    }


    private String getRealPathFromURI(Uri contentURI) {
        String result;
        Cursor cursor = getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) { // Source is Dropbox or other similar local file path
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }

}
