package com.example.lenovo.serviceprovider;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static android.media.MediaRecorder.VideoSource.CAMERA;

public class Activity_ADDShop extends AppCompatActivity implements View.OnClickListener{

    String IP_address = "10.40.39.125";


    private static final String IMAGE_DIRECTORY = "/Camera";
    private int GALLERY = 1, CAMERA = 2;

    Button upload_image;
    Button next;
    Button back;

    String image_url;
    EditText shopname;
    EditText address;
    EditText landline;

    ImageView shop_image;

    Boolean is_upload = false;

    String shopAdmin_ID;

    String shop_name;

    String shopAdmin_Name;

    TextView bar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__addshop);

        shopAdmin_ID = getSharedPreferences("shopAdmin_token", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("token", "aya");


        bar = (TextView) findViewById(R.id.toolbar_textView);
        bar.setText("Add Shop");


        //is_upload = false;

        upload_image = (Button)findViewById(R.id.upload);
        next = (Button)findViewById(R.id.next);
        back = (Button)findViewById(R.id.back);


        upload_image.setOnClickListener(this);

        next.setOnClickListener(this);
        back.setOnClickListener(this);

        shopname = (EditText)findViewById(R.id.shop_name_tv);
        address = (EditText)findViewById(R.id.address_tv);
        landline = (EditText)findViewById(R.id.landline_tv);

        shop_image = (ImageView)findViewById(R.id.dp);



    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.back:
                onBackPressed();
                break;

            case R.id.next:
            {
                // add to the database, then go to intent to choose category


                if(!(shopname.getText().toString().isEmpty()) &&!(landline.getText().toString().isEmpty()) &&!(address.getText().toString().isEmpty()))
                {
                    shop_name = shopname.getText().toString();
                    RequestQueue queue = Volley.newRequestQueue(Activity_ADDShop.this);
                    StringRequest example = new StringRequest(Request.Method.GET,
                            "http://" + IP_address + ":3000/add_shop?name=" + shopname.getText().toString() + "&landline=" + landline.getText().toString()
                            + "&address=" + address.getText().toString() + "&admin_ID=" + shopAdmin_ID,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(Activity_ADDShop.this,"Successfully added shop details", Toast.LENGTH_SHORT).show();

                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error)
                                {
                                    Toast.makeText(Activity_ADDShop.this, "Problem in adding shop details", Toast.LENGTH_SHORT).show();

                                }
                            }
                    );


                    queue.add(example);


                if(is_upload == true){   // an image was uploaded, so will save it to DB
                    ///////////////////////////////////////////////////////////////

                    //////////////////////////////////////////////////////////////
                    RequestQueue queue_new = Volley.newRequestQueue(this);

                    StringRequest example_new = new StringRequest(Request.Method.GET,
                            "http://" + IP_address + ":3000/uploadImage?path=" + "C:/Users/Lenovo/Desktop/ProjectProfiles/cherry.png",
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(Activity_ADDShop.this,"Successful Upload", Toast.LENGTH_SHORT).show();
                                    image_url = response;
                                    Toast.makeText(Activity_ADDShop.this,image_url, Toast.LENGTH_SHORT).show();


                                    ///////////////////////////////////////////////////////////////
                                    RequestQueue queue2 = Volley.newRequestQueue(Activity_ADDShop.this);
                                    StringRequest example2 = new StringRequest(Request.Method.GET,
                                            "http://" + IP_address + ":3000/update_shop_image?url=" + image_url + "&name=" + shopname.getText().toString()
                                                    + "&shopAdmin_ID=" + shopAdmin_ID,
                                            new Response.Listener<String>() {
                                                @Override
                                                public void onResponse(String response) {
                                                    Toast.makeText(Activity_ADDShop.this,"Successfully updated image url to DB", Toast.LENGTH_SHORT).show();

                                                }
                                            },
                                            new Response.ErrorListener()
                                            {
                                                @Override
                                                public void onErrorResponse(VolleyError error)
                                                {
                                                    Toast.makeText(Activity_ADDShop.this, "Problem in updating image in DB", Toast.LENGTH_SHORT).show();

                                                }
                                            }
                                    );


                                    queue2.add(example2);
                                    ////////////////////////////////////////////////////////////////


                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error)
                                {
                                    Toast.makeText(Activity_ADDShop.this, "Unsuccessful Upload", Toast.LENGTH_SHORT).show();

                                }
                            }
                    );

                    queue_new.add(example_new);

                }


                    Intent i = new Intent(Activity_ADDShop.this, Activity_ADDCategory.class);  // move to a new screen to verify the code
                    i.putExtra("shopname", shop_name);
                    startActivity(i);

                }

                else
                {
                    Toast.makeText(Activity_ADDShop.this, "PLease enter empty fields!", Toast.LENGTH_SHORT).show();
                }


            }
            break;

            case R.id.upload:
            {
                is_upload = true;    // indicates that there's a valid image URL

                // showPictureDialog();
                choosePhotoFromGallery();

            }
            break;

        }

    }


    public void choosePhotoFromGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(galleryIntent, GALLERY);
    }

    private void takePhotoFromCamera() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                Uri contentURI = data.getData();

                File my_file = new File(getRealPathFromURI(contentURI));

                Toast.makeText(Activity_ADDShop.this, my_file.getPath(), Toast.LENGTH_SHORT).show();


                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), contentURI);
                    shop_image.setImageBitmap(bitmap);

                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(Activity_ADDShop.this, "Failed!", Toast.LENGTH_SHORT).show();
                }
            }

        } else if (requestCode == CAMERA) {
            Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
            shop_image.setImageBitmap(thumbnail);

            }

    }


    private String getRealPathFromURI(Uri contentURI) {
        String result;
        Cursor cursor = getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) { // Source is Dropbox or other similar local file path
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }



}
