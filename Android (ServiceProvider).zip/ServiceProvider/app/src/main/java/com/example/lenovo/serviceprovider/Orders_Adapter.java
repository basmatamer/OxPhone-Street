package com.example.lenovo.serviceprovider;


import android.widget.ArrayAdapter;

import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class Orders_Adapter extends ArrayAdapter<String> {
    List<String> my_list;
    ArrayList<String> my_arraylist;
    Context mContext;



    public Orders_Adapter(Context context, List<String> my_list) {
        super(context,R.layout.order_list_item, my_list);
        this.my_list = my_list;
        this.my_arraylist = new ArrayList<String>();
        this.my_arraylist.addAll(my_list);
        this.mContext= context;

    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        if (convertView == null)
            convertView = LayoutInflater.
                    from(getContext()).
                    inflate(
                            R.layout.order_list_item,
                            parent,
                            false
                    );




        TextView product_name = (TextView)convertView.findViewById(R.id.Name);

        String product = getItem(position);  // the item should be sent here filled from the APIs

        product_name.setText(product);

        ///////////////////////////

        //////////////////////////////////////


        /*
        ////////////////////////
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(mContext, Activity7.class);   // to see a list of products there

                // ProductDetails product = getItem(position);
                //i.putExtra("shopName", item.shop_name);

                mContext.startActivity(i);
            }
        });

        ////////////////////////
        */

        return convertView;
    }







}




//import android.support.v4.content.ContextCompat;
//import android.widget.AdapterView;
//import android.widget.ArrayAdapter;
//
//import java.util.List;
//
//import android.content.Context;
//import android.content.Intent;
//import android.support.annotation.NonNull;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ArrayAdapter;
//import android.widget.ImageView;
//import android.widget.RatingBar;
//import android.widget.Spinner;
//import android.widget.TextView;
//
//import com.squareup.picasso.Picasso;
//
//import java.util.ArrayList;
//import java.util.List;
//
//class Orders_Adapter extends ArrayAdapter<Order> {
//
//    List<Order> my_list;
//    ArrayList<Order> my_arraylist;
//    Context mContext;
//
//
//
//    public Orders_Adapter(Context context, List<Order> my_list) {
//        super(context,R.layout.order_list_item, my_list);
//        this.my_list = my_list;
//        this.my_arraylist = new ArrayList<Order>();
//        this.my_arraylist.addAll(my_list);
//        this.mContext= context;
//
//    }
//
//
//    @Override
//    public View getView(final int position, View convertView, ViewGroup parent)
//    {
//        if (convertView == null)
//            convertView = LayoutInflater.
//                    from(getContext()).
//                    inflate(
//                            R.layout.order_list_item,
//                            parent,
//                            false
//                    );
//
//        TextView name, item;
//       // Spinner customer;
//
//        Order i = getItem(position);
//        name = (TextView) convertView.findViewById(R.id.shop_name);
//        item = (TextView) convertView.findViewById(R.id.items);
//       // customer = (Spinner) convertView.findViewById(R.id.spinner);
//
//        name.setText(i.shop_name);
//        item.setText(i.product_name);
//
////        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getContext(),
////                android.R.layout.simple_spinner_item, i.customer_name);
////        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
////        customer.setAdapter(dataAdapter);
//
//        return convertView;
//    }
//}
//
