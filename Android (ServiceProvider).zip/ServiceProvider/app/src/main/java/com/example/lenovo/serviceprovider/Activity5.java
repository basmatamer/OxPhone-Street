package com.example.lenovo.serviceprovider;    // View my Shops, and has button add shop

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

public class Activity5 extends AppCompatActivity{

    ListView mlistview;
    My_Adapter adapter;

   // SharedPreferences shared;
    String admin_ID;
    Item item;

    JSONObject obj;

    private ArrayList<Item> mEntries;
    String IP_address = "10.40.39.125";

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_5);

        admin_ID = getSharedPreferences("shopAdmin_token", MODE_PRIVATE)
                .getString("token", "hana");

        Toast.makeText(Activity5.this, admin_ID, Toast.LENGTH_SHORT).show();


        mEntries = new ArrayList<Item>();
        ////////////////////////////////////////////////////////

        RequestQueue queue = Volley.newRequestQueue(Activity5.this);
        JSONArray jsonAr = new JSONArray();
        String gurl = "http://" + IP_address + ":3000/get_shops_details?adminID=" + admin_ID;

        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, gurl, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity5.this, "Connected to The shops API", Toast.LENGTH_SHORT).show();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                item = new Item();
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                item.shop_name= obj.getString("name");
                                item.rating = obj.getString("rating");
                                item.no_orders = obj.getString("no_orders");
                                item.landline = obj.getString("landline");
                                item.address = obj.getString("address");
                                item.image_url = obj.getString("image_url");



                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            mEntries.add(item);

                        }

                        mlistview = (ListView) findViewById(R.id.my_listview);

                        ArrayList<Item> list = new ArrayList<Item>(mEntries);

                        adapter = new My_Adapter(Activity5.this, list, Activity5.this);
                        mlistview.setAdapter(adapter);
                    }
                },

            new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity5.this, "Failed to connect to Shops API.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);



        //////////////////////////////////////////////////////////

    }

}
