package com.example.lenovo.serviceprovider;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Activity3 extends AppCompatActivity implements View.OnClickListener{

    Button add_shop;
    Button view_shops;
    Button check_orders;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        add_shop = (Button) findViewById(R.id.add_shop);
        view_shops = (Button)findViewById(R.id.list_of_shops);
        check_orders = (Button)findViewById(R.id.orders);

        add_shop.setOnClickListener(this);
        view_shops.setOnClickListener(this);
        check_orders.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.add_shop:    // This button is for adding or deleting a shop
                // From it u get directed to a list of all shops you have
            {
                Intent i = new Intent(Activity3.this, Activity7.class);
                startActivity(i);
            }
            break;


            case R.id.list_of_shops:   // gives a list of shops belonging to this ShopAdmin
            {

                ////////////////////////////////////////////////////////////////////
                Intent i = new Intent(Activity3.this, Activity5.class);
                startActivity(i);
            }
            break;

            case R.id.orders:
            {
                Intent i = new Intent(Activity3.this, Activity9.class);
                startActivity(i);
            }
            break;

        }
    }
}
