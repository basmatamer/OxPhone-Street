package com.example.lenovo.project_7_8_2018_;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class listview_act7 extends ArrayAdapter<FavPage> {

    //private static final String TAG = "listview_act5";

    //vars
    List<FavPage> list_l;
    ArrayList<FavPage> list;


    public listview_act7(Context context, List<FavPage> list_l)
    {
        super(context, R.layout.list_act7, list_l);
        this.list_l = list_l;
        this.list = new ArrayList<FavPage>();
        this.list.addAll(list_l);
        Log.v("gazar", "constructor");
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        Log.v("gazar", "passed");
        if (convertView == null) // Was this cell rendered yet?
            convertView = LayoutInflater.
                    from(getContext()). // Which activity are we in right now
                    inflate(
                    R.layout.list_act7, // Desired layout - in your case, would be the custom XML
                    parent, // Just leave it as it is
                    false // Also leave it as it is
            );

        //Assume layout has imageView, titleView, subtitleView
        ImageView profile;
        TextView location, orders, phone;
        RatingBar stars;

        FavPage i = getItem(position);
        profile = (ImageView) convertView.findViewById(R.id.profile);
        location = (TextView) convertView.findViewById(R.id.location);
        orders = (TextView) convertView.findViewById(R.id.price);
        phone = (TextView) convertView.findViewById(R.id.number);
        stars = (RatingBar) convertView.findViewById(R.id.rating);


        Picasso.with(getContext()).load(i.img_url).fit().centerInside().into(profile);
        location.setText(i.location);
        orders.setText(i.orders);
        phone.setText(i.phone);
        stars.setRating(Integer.valueOf(i.rating));
        return convertView;
    }


}
