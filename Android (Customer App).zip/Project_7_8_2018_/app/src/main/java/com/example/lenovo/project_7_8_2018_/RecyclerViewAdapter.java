package com.example.lenovo.project_7_8_2018_;


import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private static final String TAG = "RecyclerViewAdapter";

    //vars
    private ArrayList<String> mLocations = new ArrayList<>();
    private ArrayList<String> mNumbers = new ArrayList<>();
    private List<String> url;
    private ArrayList<String> mOrders = new ArrayList<>();
    private ArrayList<String> mProfile = new ArrayList<>();
    private ArrayList<String> mRatings = new ArrayList<>();
    private ArrayList<ArrayList<String>> mImageUrls = new ArrayList<>();
    private ArrayList<String> mshop_ids = new ArrayList<>();
    private Context mContext;

    public RecyclerViewAdapter(Context context, ArrayList<String> locations, ArrayList<String> numbers,  ArrayList<String> orders, ArrayList<String> ratings, ArrayList<String> profiles, ArrayList<ArrayList<String>> imageUrls, ArrayList<String> shop_ids) {
        mLocations = locations;
        mNumbers = numbers;
        mProfile = profiles;
        mOrders = orders;
        mRatings = ratings;
        mImageUrls = imageUrls;
        mContext = context;
        mshop_ids = shop_ids;
    }



    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.border, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        Log.d(TAG, "onBindViewHolder: called.");
        if(!mImageUrls.get(position).get(0).isEmpty())
            Picasso.with(mContext).load(mImageUrls.get(position).get(0)).fit().centerInside().into(holder.image1);
        else
            Picasso.with(mContext).load("http://res.cloudinary.com/dutrolzkl/image/upload/v1530824651/qhfgf36cnx0rqxflnn2o.jpg").fit().centerInside().into(holder.image1);

        if(!mImageUrls.get(position).get(1).isEmpty())
            Picasso.with(mContext).load(mImageUrls.get(position).get(1)).fit().centerInside().into(holder.image2);
        else
            Picasso.with(mContext).load("http://res.cloudinary.com/dutrolzkl/image/upload/v1530824651/qhfgf36cnx0rqxflnn2o.jpg").fit().centerInside().into(holder.image2);

        if(!mImageUrls.get(position).get(2).isEmpty())
            Picasso.with(mContext).load(mImageUrls.get(position).get(2)).fit().centerInside().into(holder.image3);
        else
            Picasso.with(mContext).load("http://res.cloudinary.com/dutrolzkl/image/upload/v1530824651/qhfgf36cnx0rqxflnn2o.jpg").fit().centerInside().into(holder.image3);

        if(!mProfile.get(position).isEmpty())
            Picasso.with(mContext).load(mProfile.get(position)).fit().centerInside().into(holder.profile);
        else
            Picasso.with(mContext).load("http://res.cloudinary.com/dutrolzkl/image/upload/v1530824651/qhfgf36cnx0rqxflnn2o.jpg").fit().centerInside().into(holder.profile);

        holder.location.setText(mLocations.get(position));
        holder.number.setText(mNumbers.get(position));
        holder.orders.setText(mOrders.get(position));
        holder.stars.setRating(Integer.valueOf(mRatings.get(position)));

        holder.v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: clicked on an image: " + mLocations.get(position));
                Intent int1 = new Intent(mContext, Activity10.class);
                int1.putExtra("shop_id", mshop_ids.get(position));
                mContext.startActivity(int1);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mImageUrls.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        ImageView image1, image2, image3, profile;
        TextView location, number, orders;
        RatingBar stars;
        View v;

        public ViewHolder(View itemView) {
            super(itemView);
            image1 = (ImageView) itemView.findViewById(R.id.image1);
            image2 = (ImageView) itemView.findViewById(R.id.image2);
            image3 = (ImageView) itemView.findViewById(R.id.image3);
            profile = (ImageView) itemView.findViewById(R.id.profile);
            location = (TextView) itemView.findViewById(R.id.location);
            number = (TextView) itemView.findViewById(R.id.number);
            orders = (TextView) itemView.findViewById(R.id.price);
            stars = (RatingBar) itemView.findViewById(R.id.rating);
            v = (View) itemView.findViewById(R.id.view5);
        }
    }
}
