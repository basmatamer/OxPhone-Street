package com.example.lenovo.project_7_8_2018_;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity_Pay extends AppCompatActivity implements View.OnClickListener{

    Button cash;
    Button creditCard;
    String total_money;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__pay);

        cash = (Button)findViewById(R.id.cash);
        creditCard = (Button) findViewById(R.id.creditcard);

        cash.setOnClickListener(this);
        creditCard.setOnClickListener(this);

        creditCard.setAlpha(.5f);
        creditCard.setClickable(false);

        Bundle extras = getIntent().getExtras();
        total_money = extras.getString("total_money");


    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.cash:
            {
                Intent int3 = new Intent(this, Activity_verifyPay.class);
                int3.putExtra("total_money", total_money);
                startActivity(int3);
            }
            break;
        }

    }
}
