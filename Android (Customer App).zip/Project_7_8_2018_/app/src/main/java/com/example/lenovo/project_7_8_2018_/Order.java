package com.example.lenovo.project_7_8_2018_;

import java.util.ArrayList;

public class Order {
    ArrayList<String> customer_name = new ArrayList<>();
    String product_name;
    String shop_name;
}
