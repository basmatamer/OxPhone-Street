package com.example.lenovo.project_7_8_2018_;

public class History {
    String img_url;
    String item_name;
    String shop_name;
    String order_date;
    String price;
}
