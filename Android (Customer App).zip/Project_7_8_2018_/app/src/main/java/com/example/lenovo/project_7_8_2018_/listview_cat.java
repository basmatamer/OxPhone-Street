package com.example.lenovo.project_7_8_2018_;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class listview_cat extends ArrayAdapter<Category_Stuff> {

    List<Category_Stuff> list_l;
    ArrayList<Category_Stuff> list;
    String category_id;
    CheckBox ck;


    public listview_cat(Context context, List<Category_Stuff> list_l)
    {
        super(context, R.layout.list_cat, list_l);
        this.list_l = list_l;
        this.list = new ArrayList<Category_Stuff>();
        this.list.addAll(list_l);
        Log.v("gazar", "constructor");
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        Log.v("gazar", "passed");
        if (convertView == null) // Was this cell rendered yet?
            convertView = LayoutInflater.
                    from(getContext()). // Which activity are we in right now
                    inflate(
                    R.layout.list_cat, // Desired layout - in your case, would be the custom XML
                    parent, // Just leave it as it is
                    false // Also leave it as it is
            );

        //Assume layout has imageView, titleView, subtitleView
        TextView cat_name;

        Category_Stuff i = getItem(position);
        cat_name = (TextView) convertView.findViewById(R.id.cat_name);
        i.ck = (CheckBox) convertView.findViewById(R.id.checkBox);

        cat_name.setText(i.cat_name);
        i.ck.setEnabled(false);
        i.ck.setTag(i);
        i.ck.setChecked(i.checked);

        /*convertView.setClickable(true);
        convertView.setFocusable(true);
        Log.v("gazarV", String.valueOf(position));

        switch (String.valueOf(position))
        {
            case "1":
                category_id = "1";
                break;

            case "2":
                category_id = "2";
                break;

            case "3":
                category_id = "3";
                break;

            case "4":
                category_id = "4";
                break;
            case "5":
                category_id = "5";
            case "6":
                category_id = "6";
                break;
            case "7":
                category_id = "7";
                break;
        }

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i.checked = !i.checked;
                ck.setChecked(i.checked);


                if(i.checked == true)
                {

                    Log.v("gazarV",category_id);
                    add_cat("1", category_id);
                }
                else
                {
                    Log.v("gazarV",category_id);
                    delete_cat("1", category_id);
                }
            }

        });
                  ck.setChecked(i.checked);
        //image.setImageDrawable(Drawable.createFromStream(is, ""));*/
        return convertView;
    }

}
