package com.example.lenovo.project_7_8_2018_;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;


public class Activity3 extends AppCompatActivity implements View.OnClickListener{

    Button my_login;
    Button my_back;
    Button forgot_password;

    EditText username;
    EditText password;

    String retreived_mail, reset_code;

    CheckBox login_checkBox;

    SharedPreferences shared;

    String customer_ID;

    // String IP_address = "192.168.1.6";
    String IP_address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        IP_address = getSharedPreferences("IP_ADDRESS", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("ip_address", "aya");

        my_login = (Button) findViewById(R.id.login_button);
        my_back = (Button)findViewById(R.id.back_button);
        forgot_password = (Button) findViewById(R.id.forgotpassword);

        username = (EditText) findViewById(R.id.username_tv);
        password = (EditText) findViewById(R.id.password_tv);

        login_checkBox = (CheckBox) findViewById(R.id.checkBox);

        my_login.setOnClickListener(this);
        my_back.setOnClickListener(this);
        forgot_password.setOnClickListener(this);
        login_checkBox.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId())
        {
            case R.id.login_button:
            {
                RequestQueue queue = Volley.newRequestQueue(this);

                StringRequest example = new StringRequest(Request.Method.GET,
                        "http://" + IP_address + ":3000/login?name=" + username.getText().toString() + "&password=" + password.getText().toString(),
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                // Toast.makeText(Activity3.this,"Successful Access to Login API", Toast.LENGTH_SHORT).show();
                                Toast.makeText(Activity3.this,response, Toast.LENGTH_SHORT).show();

                                ////////////////////////////////////////////////////
                                if(response.equals("0")){  // this means eno 7asal moshkela ma fl login
                                    Toast.makeText(Activity3.this,"Wrong username or password or unverified account! Please Try Again later! ", Toast.LENGTH_SHORT).show();
                                }

                                else if(response.equals("1")){

                                  //  getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                                  //          .putBoolean("isLoggedinBefore", true).commit();


                                    ////////////// Call the API to save the ID in shared preference

                                    RequestQueue queue3 = Volley.newRequestQueue(Activity3.this);
                                    StringRequest example3 = new StringRequest(Request.Method.GET,
                                            "http://" + IP_address + ":3000/get_customerID?customer_name=" + username.getText().toString(),
                                            new Response.Listener<String>() {
                                                @Override
                                                public void onResponse(String response) {
                                                   // Toast.makeText(Activity3.this,"Successfully retreived customer ID", Toast.LENGTH_SHORT).show();

                                                    shared = getSharedPreferences("Customer_token", Context.MODE_PRIVATE);
                                                    final SharedPreferences.Editor editor = shared.edit();

                                                    customer_ID = response;
                                                    editor.putString("token", customer_ID);
                                                    editor.commit();

                                                    Toast.makeText(Activity3.this,customer_ID, Toast.LENGTH_SHORT).show();

                                                    Intent i = new Intent(Activity3.this, Activity5.class);   // move to explore activity
                                                    startActivity(i);
                                                    finish();


                                                }
                                            },
                                            new Response.ErrorListener()
                                            {
                                                @Override
                                                public void onErrorResponse(VolleyError error)
                                                {
                                                    Toast.makeText(Activity3.this, "Problem in retreiving customer ID", Toast.LENGTH_SHORT).show();

                                                }
                                            }
                                    );


                                    queue3.add(example3);



                                }

                                ///////////////////////////////////////////////////

                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error)
                            {
                                Toast.makeText(Activity3.this, "Unsuccessful Login", Toast.LENGTH_SHORT).show();

                            }
                        }
                );

                queue.add(example);

            }
            break;

            case R.id.back_button:
                onBackPressed();
            break;


            case R.id.forgotpassword:
            {
                RequestQueue queue = Volley.newRequestQueue(this);
                StringRequest example = new StringRequest(Request.Method.GET,
                        "http://" + IP_address + ":3000/get_email_from_name?name=" + username.getText().toString(),
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                //Toast.makeText(Activity3.this, "Successful mail retreival", Toast.LENGTH_SHORT).show();

                                if(response.equals("NULL"))
                                {
                                    Toast.makeText(Activity3.this, "Unknown username! Please try again!", Toast.LENGTH_SHORT).show();
                                }

                                else
                                {
                                    retreived_mail = response;
                                    //////////////////////////////////////////

                                    // Generate a random code and send it to mail then pass this code to next activity to check for correctness
                                    reset_code = GenerateRandomString.randomString(6);

                                    /////////////////// Send the email
                                    try {

                                        String to = retreived_mail;
                                        String subject = "Code to Reset Password";
                                        String message = "Dear " + username.getText()+ ", \n" + "This is to reset your OxphoneSt account password. \n" + "Please enter the following code in your app: " + reset_code;


                                        if(to.isEmpty()){
                                            Toast.makeText(Activity3.this, "You must enter a recipient email", Toast.LENGTH_LONG).show();
                                        }else if(subject.isEmpty()){
                                            Toast.makeText(Activity3.this, "You must enter a Subject", Toast.LENGTH_LONG).show();
                                        }else if(message.isEmpty()){
                                            Toast.makeText(Activity3.this, "You must enter a message", Toast.LENGTH_LONG).show();
                                        }else {
                                            //everything is filled out
                                            //send email
                                            new SimpleMail().sendEmail(to, subject, message);
                                        }

                                    } catch (Exception e) {
                                        e.printStackTrace();

                                    }

                                    ///////////////////////////////////////////////

                                    Intent i = new Intent(Activity3.this, Activity3_5.class);  // move to a new screen to verify the code
                                    i.putExtra("reset_code", reset_code);
                                    i.putExtra("mail", retreived_mail);
                                    i.putExtra("user_name", username.getText().toString());
                                    startActivity(i);
                                    finish();
                                    ////////////////////////////////////////////////////////////////
                                }

                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error)
                            {
                                Toast.makeText(Activity3.this, "Unsuccessful mail retreival", Toast.LENGTH_SHORT).show();

                            }
                        }
                );

                queue.add(example);

            }
            break;


            case R.id.checkBox:    // this means he wants to stay logged in so next time el mafrood lama yfta7 el app afta7lo explore 3la tol
            {
                // will have a shared preference that indicates this
                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                        .putBoolean("iskeepMeLoggedin", true).commit();

            }

            break;

        }

    }
}
