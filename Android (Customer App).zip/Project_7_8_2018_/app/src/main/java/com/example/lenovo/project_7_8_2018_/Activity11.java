package com.example.lenovo.project_7_8_2018_;

import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

//import static com.example.habibaashraf.activity_design.R.drawable.heart;

public class Activity11 extends AppCompatActivity implements  View.OnClickListener {

    ImageView item_img;
    TextView description, price,bar;
    Spinner material, size;
    History history = new History();
    Button heart, cart, c;
    int counter= 0;
    int counter2 = 0;
    //String IP_address="192.168.1.7";
    String IP_address;
    String customer_ID;

    List<String> colors = new ArrayList<String>();
    List<String> sizes = new ArrayList<String>();
    ArrayList<String> ids =  new ArrayList<>();
    JSONObject obj;
    String desc, img_url, price_item;
    int color_id, size_id;
    String SAI;

    Button bar_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_11);

        IP_address = getSharedPreferences("IP_ADDRESS", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("ip_address", "aya");

        Bundle extras = getIntent().getExtras();
        String IN = extras.getString("item_name");
        String SI = extras.getString("shop_id");
        SAI = extras.getString("shop_admin_id");
        Log.v("ayaGAZAR", SAI);
        customer_ID = getSharedPreferences("Customer_token", MODE_PRIVATE).getString("token" ,"aya");

        item_img = (ImageView) findViewById(R.id.img);
        description = (TextView) findViewById(R.id.desc);
        price = (TextView) findViewById(R.id.price);
        heart = (Button) findViewById(R.id.heart);
        cart = (Button) findViewById(R.id.go_cart);
        c = (Button) findViewById(R.id.go_cart);
        bar = (TextView) findViewById(R.id.textView_toolBar);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        Log.v("gazarINTENT1", IN);
        Log.v("gazarINTENT1", SI);
        get_product_item(IN, SI);

        bar_back = (Button)findViewById(R.id.bar_back_button);
        bar_back.setOnClickListener(this);
    }

    public void addItemsOnSpinner2() {

        material = (Spinner) findViewById(R.id.material);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, colors);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        material.setAdapter(dataAdapter);
    }

    public void addItemsOnSpinner1() {

        size = (Spinner) findViewById(R.id.size);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, sizes);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        size.setAdapter(dataAdapter);
    }

    public void addListenerOnSpinnerItemSelection() {
        material = (Spinner) findViewById(R.id.material);
        material.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // your code here
                if(position != color_id)
                {
                    counter = 0;
                    heart.setBackground(ContextCompat.getDrawable(Activity11.this, R.drawable.heart));
                    c.setBackground(ContextCompat.getDrawable(Activity11.this, R.drawable.cart));
                    counter2 = 0;
                }
                color_id = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }
        });

        size = (Spinner) findViewById(R.id.size);
        size.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // your code here
                if(position != size_id)
                {
                    counter = 0;
                    heart.setBackground(ContextCompat.getDrawable(Activity11.this, R.drawable.heart));
                    c.setBackground(ContextCompat.getDrawable(Activity11.this, R.drawable.cart));
                    counter2 = 0;
                }
                size_id = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

    }

    private void get_product_item(final String name, final String id)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        Log.v("gazarURL", "http://"+IP_address+":3000/get_product_item?name="+name+"&id="+id);
        String url= "http://"+IP_address+":3000/get_product_item?name="+name+"&id="+id;
        JSONArray jsonAr = new JSONArray();
        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity11.this, "Connected to get_cart", Toast.LENGTH_SHORT).show();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                Log.v("gazarP", "I am here inside the for loop get_cart");
                                desc = obj.getString("description");
                                img_url = obj.getString("image_url");
                                price_item = obj.getString("price");
                                colors.add(obj.getString("color"));
                                ids.add(obj.getString("p_id"));
                                sizes.add(obj.getString("size"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                        price.setText(price_item+" LE");
                        description.setText(desc);
                        bar.setText(name);
                        addItemsOnSpinner2();
                        addItemsOnSpinner1();
                        addListenerOnSpinnerItemSelection();
                        if(img_url != null && !img_url .isEmpty())
                            Picasso.with(Activity11.this).load(img_url).fit().centerInside().into(item_img);
                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity11.this, "Failed to connect to get_cart. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void add_fav_item(String c_id, String p_id)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/add_fav_item?cus_id="+c_id+"&p_id="+p_id;
        JSONObject jsonAr = new JSONObject();
        JsonObjectRequest jsonArRequest = new JsonObjectRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONObject>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity11.this, "Connected to add_fav_item", Toast.LENGTH_SHORT).show();

                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity11.this, "It already exists", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void add_cart_item(String c_id, String p_id)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/add_cart_item?cus_id="+c_id+"&p_id="+p_id+"&sa_id="+SAI;
        Log.v("addCart", url);
        JSONObject jsonAr = new JSONObject();
        JsonObjectRequest jsonArRequest = new JsonObjectRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONObject>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity11.this, "Connected to add_cart_item", Toast.LENGTH_SHORT).show();

                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity11.this, "It already exists", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void delete_cart_item(String c_id, String p_id)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/delete_cart_item?cus_id="+c_id+"&p_id="+p_id+"&sa_id="+SAI;
        JSONObject jsonAr = new JSONObject();
        JsonObjectRequest jsonArRequest = new JsonObjectRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONObject>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity11.this, "Connected to delete_cart_item", Toast.LENGTH_SHORT).show();

                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity11.this, "Failed to connect to delete_cart_item. Try again Later", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void delete_fav_item(String c_id, String p_id)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/delete_fav_item?cus_id="+c_id+"&p_id="+p_id;
        JSONObject jsonAr = new JSONObject();
        JsonObjectRequest jsonArRequest = new JsonObjectRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONObject>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity11.this, "Connected to delete_fav_item", Toast.LENGTH_SHORT).show();

                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity11.this, "Failed to connect to delete_fav_item. Try again Later", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.history:
                Intent int1 = new Intent(this, Activity8.class);
                startActivity(int1);
                finish();
                break;
            case R.id.favorite:
                Intent int2 = new Intent(this, Activity7.class);
                startActivity(int2);
                finish();
                break;
            case R.id.cart:
                Intent int3 = new Intent(this, Activity9.class);
                startActivity(int3);
                finish();
                break;
            case R.id.explore:
                Intent int4 = new Intent(this, Activity5.class);
                startActivity(int4);
                finish();
                break;
            case R.id.go_cart:
                if(counter2 == 0)
                {
                    if(color_id==size_id) {
                        cart.setBackground(ContextCompat.getDrawable(this, R.drawable.bag2));
                        Log.v("gazarAYA", ids.get(color_id));
                        add_cart_item(customer_ID, ids.get(color_id));
                        counter2 = 1;
                    }
                    else
                        Toast.makeText(Activity11.this, "Item Not Available ", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    c.setBackground(ContextCompat.getDrawable(this, R.drawable.cart));
                    delete_cart_item(customer_ID,  ids.get(color_id));
                    counter2 = 0;
                }
                break;
            case R.id.heart:
                if(counter == 0)
                {
                    if(color_id==size_id) {

                        heart.setBackground(ContextCompat.getDrawable(this, R.drawable.fave2));
                        add_fav_item(customer_ID, ids.get(color_id));
                        counter = 1;
                    }
                    else
                        Toast.makeText(Activity11.this, "Item Not Available ", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    heart.setBackground(ContextCompat.getDrawable(this, R.drawable.heart));
                    delete_fav_item(customer_ID,  ids.get(color_id));
                    counter = 0;
                }
                break;


            case R.id.categories:
                Intent int_4 = new Intent(this, Activity15.class);
                startActivity(int_4);
                //finish();
                break;


            case R.id.editprofile:
            {
                Intent i3 = new Intent(Activity11.this, Activity14.class);
                startActivity(i3);
            }
            break;

            case R.id.logout_button:       // logout button
            {
                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                        .putBoolean("iskeepMeLoggedin", false).commit();

                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                        .putBoolean("isLoggedinBefore", false).commit();

                getSharedPreferences("Customer_token", MODE_PRIVATE).edit()
                        .remove("token").commit();

                Intent i = new Intent(Activity11.this, MainActivity.class);
                startActivity(i);
                finish();
            }
            break;

            case R.id.bar_back_button:
                onBackPressed();
            break;
        }
    }

}

