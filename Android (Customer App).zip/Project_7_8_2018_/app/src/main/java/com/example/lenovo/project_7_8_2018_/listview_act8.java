package com.example.lenovo.project_7_8_2018_;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class listview_act8 extends ArrayAdapter<History> {

    //private static final String TAG = "listview_act5";

    //vars
    List<History> list_l;
    ArrayList<History> list;


    public listview_act8(Context context, List<History> list_l)
    {
        super(context, R.layout.list_act8, list_l);
        this.list_l = list_l;
        this.list = new ArrayList<History>();
        this.list.addAll(list_l);
        Log.v("gazar", "constructor");
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        Log.v("gazar", "passed");
        if (convertView == null) // Was this cell rendered yet?
            convertView = LayoutInflater.
                    from(getContext()). // Which activity are we in right now
                    inflate(
                    R.layout.list_act8, // Desired layout - in your case, would be the custom XML
                    parent, // Just leave it as it is
                    false // Also leave it as it is
            );

        //Assume layout has imageView, titleView, subtitleView
        ImageView profile;
        TextView shop_name, item_name, price, order_date, order_date_fixed;

        History i = getItem(position);
        profile = (ImageView) convertView.findViewById(R.id.profile);
        shop_name = (TextView) convertView.findViewById(R.id.shop_name);
        item_name = (TextView) convertView.findViewById(R.id.item_name);
        price = (TextView) convertView.findViewById(R.id.price);
        order_date = (TextView) convertView.findViewById(R.id.order_date);
        order_date_fixed = (TextView) convertView.findViewById(R.id.orders);

        if(i.img_url != null && !i.img_url .isEmpty())
            Picasso.with(getContext()).load(i.img_url).fit().centerInside().into(profile);
        shop_name.setText(i.shop_name);
        item_name.setText(i.item_name);
        price.setText(i.price);
        order_date.setText(i.order_date);
      //  if(i.order_date.isEmpty())
        //    order_date_fixed.setAlpha(0.0f);
        //image.setImageDrawable(Drawable.createFromStream(is, ""));
        return convertView;
    }


}
