package com.example.lenovo.project_7_8_2018_;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;


public class Activity_verifyPay extends AppCompatActivity implements View.OnClickListener{

    CheckBox old_address;
    CheckBox confirm_money;

    TextView money_txt;

    String total_money;

    Button save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_pay);

        save = (Button) findViewById(R.id.confirm);

        money_txt = (TextView)findViewById(R.id.textView19);

        Bundle extras = getIntent().getExtras();
        total_money = extras.getString("total_money");

        money_txt.setText(total_money + "LE");

        save.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        ////// UPON PRESSING ON SAVE, INFORM THE SHOP ADMIN ENO SOMETHING IS ADDED TO HIM

        Intent int4 = new Intent(Activity_verifyPay.this, Activity5.class);
        startActivity(int4);
    }
}
