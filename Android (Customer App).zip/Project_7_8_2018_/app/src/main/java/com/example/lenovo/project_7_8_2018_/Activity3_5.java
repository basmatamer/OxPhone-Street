package com.example.lenovo.project_7_8_2018_;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Activity3_5 extends AppCompatActivity implements View.OnClickListener {

    Button next;
    Button resend;

    EditText d1;
    EditText d2;
    EditText d3;
    EditText d4;
    EditText d5;
    EditText d6;

    String inputted_code;
    String correct_code;
    String mail;
    String username;

   // String IP_address = "192.168.1.6";
    String IP_address;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3_5);

        IP_address = getSharedPreferences("IP_ADDRESS", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("ip_address", "aya");

        next = (Button) findViewById(R.id.next_button);
        resend = (Button)findViewById(R.id.resend_button);

        d1 = (EditText)findViewById(R.id.digitl);
        d2 = (EditText)findViewById(R.id.digit2);
        d3 = (EditText)findViewById(R.id.digit3);
        d4 = (EditText)findViewById(R.id.digit4);
        d5 = (EditText)findViewById(R.id.digit5);
        d6 = (EditText)findViewById(R.id.digit6);

        next.setOnClickListener(this);
        resend.setOnClickListener(this);


        Bundle extras = getIntent().getExtras();
        correct_code = extras.getString("reset_code");
        mail = extras.getString("mail");
        username = extras.getString("user_name");

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.next_button:
            {
                inputted_code = d1.getText().toString()+ d2.getText().toString()+ d3.getText().toString()+
                        d4.getText().toString() + d5.getText().toString() + d6.getText().toString();

                if(inputted_code.equals(correct_code))
                {
                    Intent i = new Intent(Activity3_5.this, Activity3_6.class);  // move to a new screen to verify the code
                    i.putExtra("user_name", username);
                    startActivity(i);
                    finish();
                }

                else
                {
                    Toast.makeText(Activity3_5.this, "You inputted a wrong reset code! Please Try again", Toast.LENGTH_SHORT).show();
                }

            }

            break;


            case R.id.resend_button:
            {
                correct_code = GenerateRandomString.randomString(6);
                /////////////////// Send the email
                try {

                    String to = mail;
                    String subject = "Code to Reset Password";
                    String message = "Dear " + username+ ", \n" + "This is to reset your OxphoneSt account password. \n" + "Please enter the following code in your app: " + correct_code;


                    if(to.isEmpty()){
                        Toast.makeText(Activity3_5.this, "You must enter a recipient email", Toast.LENGTH_LONG).show();
                    }else if(subject.isEmpty()){
                        Toast.makeText(Activity3_5.this, "You must enter a Subject", Toast.LENGTH_LONG).show();
                    }else if(message.isEmpty()){
                        Toast.makeText(Activity3_5.this, "You must enter a message", Toast.LENGTH_LONG).show();
                    }else {
                        //everything is filled out
                        //send email
                        new SimpleMail().sendEmail(to, subject, message);
                    }

                } catch (Exception e) {
                    e.printStackTrace();

                }

            }
            break;
        }

    }
}
