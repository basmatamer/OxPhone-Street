package com.example.lenovo.project_7_8_2018_;

import android.content.Intent;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

public class Activity9 extends AppCompatActivity implements  View.OnClickListener {

    listview_act8 adapter_list;
    ListView Vlist;
    ArrayList<History> arr =  new ArrayList<>();
    ArrayList<History> list_h;
    TextView total, bar;
    Integer total_cal = 0;
    Integer counter = 0;
    Integer all = 0;
    History f;
    String id, s_id;

    //String IP_address="192.168.1.7";
    String IP_address;
    String shop_admin;
    JSONObject obj;
    ArrayList<String> img_url=  new ArrayList<>();
    ArrayList<String> item_name=  new ArrayList<>();
    ArrayList<String> shop_name=  new ArrayList<>();
    ArrayList<String> price=  new ArrayList<>();
    Boolean flag = false;
    ArrayList<String> p_id = new  ArrayList<>();

    String customer_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_9);

        IP_address = getSharedPreferences("IP_ADDRESS", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("ip_address", "aya");

        new navbar().create((DrawerLayout) this.findViewById(R.id.drawer_layout), Activity9.this);

        bar = (TextView) findViewById(R.id.textView_toolBar);
        bar.setText("Cart");

        total = (TextView) findViewById(R.id.total);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        customer_ID = getSharedPreferences("Customer_token", MODE_PRIVATE).getString("token" ,"aya");
        get_cart(customer_ID);
    }

    private void get_cart(String c_id)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/get_cart?cus_id="+c_id;
        JSONArray jsonAr = new JSONArray();
        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity9.this, "Connected to get_cart", Toast.LENGTH_SHORT).show();
                        all = response.length();
                        Log.v("gazarLength", String.valueOf(response));
                        if (response.length() == 0)
                        {
                            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                        }
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                Log.v("gazarP", "I am here inside the for loop get_cart");
                                id=obj.getString("cart_p_id");
                                Log.v("gazarP_ID", id);
                                p_id.add(id);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            get_product_history(id);
                        }
                        Log.v("gazarP", "I am here after the for loop get cart");
                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity9.this, "Failed to connect to get_cart. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void get_product_history(final String id)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/get_product_history?p_id="+id;
        JSONArray jsonAr = new JSONArray();
        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity9.this, "Connected to get_product_history", Toast.LENGTH_SHORT).show();
                        if (response.length() == 0)
                        {
                            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                        }
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                Log.v("gazarP", "I am here inside the for loop get_product_history");
                                item_name.add(obj.getString("name"));
                                Log.v("gazarPS", obj.getString("name"));
                                img_url.add(obj.getString("image_url"));
                                Log.v("gazarPS", obj.getString("image_url"));
                                price.add(obj.getString("price"));
                                Log.v("gazarPS", obj.getString("price"));
                                s_id = obj.getString("shop_id");
                                Log.v("gazarPS", s_id);
                                /*if (flag)
                                {
                                    checkout(customer_ID, id, price.get(counter));
                                }*/
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            if(!s_id.equals("null")) {
                                get_shop(s_id);
                                Log.v("gazarInside", "ana da5lt bardo");
                            }
                            else
                                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                        }

                        Log.v("gazarP", "I am here after the for loop get product history");
                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity9.this, "Failed to connect to get_product_history. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void get_shop(String id)
    {
        RequestQueue queue = Volley.newRequestQueue(Activity9.this);
        String url3="http://"+IP_address+":3000/get_shop?s_id="+id;
        JSONArray jsonAr3 = new JSONArray();
        JsonArrayRequest example_3 = new JsonArrayRequest(Request.Method.GET, url3, jsonAr3,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        Toast.makeText(Activity9.this, "Connected to get_shop", Toast.LENGTH_SHORT).show();
                        for (int j = 0; j < response.length(); j++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(j);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                shop_name.add(obj.getString("name"));
                                shop_admin = obj.getString("s_admin_id");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            //Log.v("gazarP", String.valueOf(img_url));
                            Log.v("gazarP", "I am here inside the for loop get shop");
                            f= new History();
                            f.img_url = img_url.get(counter);
                            f.item_name = item_name.get(counter);
                            f.price = price.get(counter);
                            f.shop_name = shop_name.get(counter);
                            arr.add(f);
                            counter++;
                        }
                        //Log.v("gazarC", String.valueOf(arr));
                        Log.v("gazarP", "I am here after the for loop get shop");
                        Log.v("gazarP shop name", String.valueOf(shop_name));
                        if(counter == all)
                        {list_h = new ArrayList<History>(arr);
                        adapter_list = new listview_act8(Activity9.this, list_h);
                        bar = (TextView) findViewById(R.id.textView_toolBar);
                        bar.setText("Cart");
                        Vlist = (ListView) findViewById(R.id.p_list);
                        Vlist.setAdapter(adapter_list);
                        Vlist.setOnItemClickListener(new AdapterView.OnItemClickListener() { //Create new object
                            @Override // Override method in object
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                Log.v("Pressed", "" + position);
                                Toast.makeText(Activity9.this, "Pressed", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(Activity9.this, Activity11.class);
                                History history = arr.get(position);
                                i.putExtra("item_name", history.item_name);
                                i.putExtra("shop_id", id);
                                i.putExtra("shop_admin_id", shop_admin);
                                startActivity(i);
                            }
                        });
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                        total_cal = getTotal();
                        total.setText(total_cal.toString());}
                    }
                },
                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Activity9.this, "Failed to connect to get_shop. Try again later.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        queue.add(example_3);


    }

    private void checkout(String c_id, String p_id, String price)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/checkout?cus_id="+c_id+"&p_id="+p_id+"&price="+ price;
        JSONObject jsonAr = new JSONObject();
        JsonObjectRequest jsonArRequest = new JsonObjectRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONObject>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity9.this, "Connected to checkout", Toast.LENGTH_SHORT).show();

                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity9.this, "Failed to connect to checkout. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private Integer getTotal(){
        Integer cal_total = 0;
        for(int i =0; i< arr.size(); i++)
        {
            cal_total = cal_total + Integer.valueOf(arr.get(i).price);
        }
        return cal_total;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.history:
                Intent int1 = new Intent(this, Activity8.class);
                startActivity(int1);
                finish();
                break;
            case R.id.favorite:
                Intent int2 = new Intent(this, Activity7.class);
                startActivity(int2);
                finish();
                break;
            case R.id.explore:
                Intent int3 = new Intent(this, Activity5.class);
                startActivity(int3);
                finish();
                break;
            case R.id.checkout:
                if(total_cal!= 0)
                {
                    flag = true;
                    Toast.makeText(Activity9.this, "ana mesh sha3'al madoseesh 3alya tany", Toast.LENGTH_SHORT).show();
                    for(int i = 0; i<all; i++)
                        checkout(customer_ID, p_id.get(i), price.get(i));

                    Intent in = new Intent(this, Activity_Pay.class);

                    in.putExtra("total_money", String.valueOf(total_cal));

                    startActivity(in);
                }

                else
                    Toast.makeText(Activity9.this, "Nothing to checkout", Toast.LENGTH_SHORT).show();

                break;


            case R.id.categories:
                Intent int4 = new Intent(this, Activity15.class);
                startActivity(int4);
                //finish();
                break;


            case R.id.editprofile:
            {
                Intent i3 = new Intent(Activity9.this, Activity14.class);
                startActivity(i3);
            }
            break;

            case R.id.logout_button:       // logout button
            {
                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                        .putBoolean("iskeepMeLoggedin", false).commit();

                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                        .putBoolean("isLoggedinBefore", false).commit();

                getSharedPreferences("Customer_token", MODE_PRIVATE).edit()
                        .remove("token").commit();

                Intent i = new Intent(Activity9.this, MainActivity.class);
                startActivity(i);
                finish();
            }
            break;


        }
    }
}
