package com.example.lenovo.project_7_8_2018_;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Activity2 extends AppCompatActivity implements View.OnClickListener{

    Button back_button;
    Button next_button;

    EditText username, email, password, confirm_password, mobilenumber, address;

    String code;

    //String IP_address = "192.168.1.6";

    String IP_address;

    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_2);

        IP_address = getSharedPreferences("IP_ADDRESS", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("ip_address", "aya");


            back_button = (Button) findViewById(R.id.back);
            next_button = (Button) findViewById(R.id.next);

            username = (EditText) findViewById(R.id.name_tv);
            email = (EditText) findViewById(R.id.email_tv);
            password = (EditText) findViewById(R.id.password_tv);
            confirm_password = (EditText)findViewById(R.id.confirmpassword_tv);
            mobilenumber = (EditText) findViewById(R.id.mobilenumber_tv);
            address = (EditText)findViewById(R.id.address_tv);

            next_button.setOnClickListener(this);
            back_button.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.back:
                    onBackPressed();
                    break;

                case R.id.next:
                {
                    ////////// API request
                   if(password.getText().toString().equals(confirm_password.getText().toString()) && !(username.getText().toString().isEmpty()) &&!(email.getText().toString().isEmpty()) &&!(mobilenumber.getText().toString().isEmpty()) && !(address.getText().toString().isEmpty())
                           && !(password.getText().toString().isEmpty()))
                   {
                    RequestQueue queue = Volley.newRequestQueue(this);

                    StringRequest example = new StringRequest(Request.Method.GET,
                            "http://" + IP_address+ ":3000/customer_signup?name=" + username.getText().toString() + "&email=" + email.getText().toString() +
                                    "&password=" + password.getText().toString() + "&mobilenumber=" + mobilenumber.getText().toString() + "&address=" + address.getText().toString(),
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(Activity2.this,"NEXT Established", Toast.LENGTH_SHORT).show();
                                    code = response.toString();

                                    //System.out.println(response);

                                    try {

                                        String to = email.getText().toString();
                                        String subject = "Verification Code";
                                        String message = "Thank you for joining our platform, we promise you the best user experience. \n" +  "This is the verification code: " + code + "\n" + " Please input it in the app to verify your account.";

                                        if(to.isEmpty()){
                                            Toast.makeText(Activity2.this, "You must enter a recipient email", Toast.LENGTH_LONG).show();
                                        }else if(subject.isEmpty()){
                                            Toast.makeText(Activity2.this, "You must enter a Subject", Toast.LENGTH_LONG).show();
                                        }else if(message.isEmpty()){
                                            Toast.makeText(Activity2.this, "You must enter a message", Toast.LENGTH_LONG).show();
                                        }else {
                                            //everything is filled out
                                            //send email
                                            new SimpleMail().sendEmail(to, subject, message);
                                        }

                                    } catch (Exception e) {
                                        e.printStackTrace();

                                    }


                                    ////////////////////////////////////////////////////
                                    Intent i = new Intent(Activity2.this, Activity2_5.class);  // move to verify screen
                                    i.putExtra("register_email", email.getText().toString());   // pass the inputted email
                                    i.putExtra("my_username", username.getText().toString());
                                    startActivity(i);
                                    finish();

                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error)
                                {
                                    Toast.makeText(Activity2.this, "Connection error. Try Again Later", Toast.LENGTH_SHORT).show();

                                }
                            }
                    );

                    queue.add(example);

                    ///////////////////////////////////////////////////  LOGIC OF SENDING EMAIL WITH VERIFICATION CODE

                    }

                    else{
                        Toast.makeText(Activity2.this, "Wrong or missing Entries!", Toast.LENGTH_SHORT).show();
                    }
                }
                break;
            }
        }

    }
