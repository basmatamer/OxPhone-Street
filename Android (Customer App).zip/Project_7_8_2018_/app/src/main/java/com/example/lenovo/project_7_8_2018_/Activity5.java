package com.example.lenovo.project_7_8_2018_;    // responsible for trial for logout

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;




public class Activity5 extends AppCompatActivity implements View.OnClickListener{

    private ArrayList<String> mLocations = new ArrayList<>();
    private ArrayList<String> mNumbers = new ArrayList<>();
    private ArrayList<String> mOrders = new ArrayList<>();
    private ArrayList<String> mRatings  = new ArrayList<>();
    private ArrayList<String> mshop_ids  = new ArrayList<>();
    private ArrayList<String> img_urls;

    private ArrayList<String> p_img = new ArrayList<>();
    private ArrayList<String> p_prices = new ArrayList<>();
    private ArrayList<String> p_shop_ids = new ArrayList<>();
    private ArrayList<String> p_shop_names = new ArrayList<>();
    private ArrayList<String> p_shop_admin = new ArrayList<>();
    private ArrayList<String> p_names = new ArrayList<>();

    ArrayList<String> mProfile = new ArrayList<>();

    private ArrayList<ArrayList<String>> mImageUrls = new ArrayList<>();
    listview_act5 adapter_list;
    ListView Vlist;
    ArrayList<String> mPic = new ArrayList<>();
    ArrayList<String> mItems = new ArrayList<>();
    ArrayList<String> mNames = new ArrayList<>();
    ArrayList<String> mPrices = new ArrayList<>();

    Item[] arr = {};
    Integer counter =0;
    Integer all=0;
    Integer all_cats=0;
    Integer all_shop_cats=0;
    Integer counter_horizontal=0;
    Integer counter_shops = 0;
    ArrayList<Item> products = new ArrayList<>();
    Item item;
    ArrayList<Item> list_h;
    String cat_id, s_id;
    JSONObject obj;
    String shop_name;

    TextView bar;


    // String IP_address="192.168.1.7";
    String IP_address;

    Button bar_back_button;

    String customer_ID;

    @SuppressLint("ResourceAsColor")


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_5);

        IP_address = getSharedPreferences("IP_ADDRESS", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("ip_address", "aya");


        customer_ID = getSharedPreferences("Customer_token", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("token", "aya");

        bar_back_button = (Button)findViewById(R.id.bar_back_button);
        bar_back_button.setOnClickListener(this);

        bar = (TextView) findViewById(R.id.textView_toolBar);
        bar.setText("Explore");


        new navbar().create((DrawerLayout) this.findViewById(R.id.drawer_layout), Activity5.this);


        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/get_categories?customer_ID=" + customer_ID;
        JSONArray jsonAr = new JSONArray();
        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                       // Toast.makeText(Activity5.this, "Connected to get_categories", Toast.LENGTH_SHORT).show();
                        Toast.makeText(Activity5.this, customer_ID, Toast.LENGTH_SHORT).show();

                        for (int i = 0; i < response.length(); i++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                Log.v("gazar2", Integer.valueOf(i).toString());
                                cat_id = obj.getString("RelationCategoryID");
                                get_shops_category(cat_id);
                                get_product_categories(cat_id);
                                Log.v("RelationCategoryID", cat_id);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity5.this, "Failed to connect to get_categories. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);


    }

    private void getImages(){
        //   Log.d(TAG, "initImageBitmaps: preparing bitmaps.");
        initRecyclerView();

    }

    private void initRecyclerView(){
        //Log.d(TAG, "initRecyclerView: init recyclerview");

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(layoutManager);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, mLocations, mNumbers, mOrders,mRatings, mProfile,mImageUrls, mshop_ids);
        recyclerView.setAdapter(adapter);
    }

    private void get_shops_category(String id){
        RequestQueue queue = Volley.newRequestQueue(Activity5.this);
        JSONArray jsonAr2 = new JSONArray();
        String url2 = "http://"+IP_address+":3000/get_shops_cateory?cat_id="+ id;
        JsonArrayRequest example_3 = new JsonArrayRequest(Request.Method.GET, url2, jsonAr2,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        Toast.makeText(Activity5.this, "Connected to get_shops_category", Toast.LENGTH_SHORT).show();
                        all_cats = all_cats + response.length();
                        for (int j = 0; j < response.length(); j++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(j);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                s_id = obj.getString("RelationshopID");
                                counter_shops++;
                                get_shop_horizontal(s_id);
                                Log.v("gazar1", s_id);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Activity5.this, "Failed to connect to get_shops_category. Try again later.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        queue.add(example_3);
    }

    private void get_shop_veritcal(String id) {

        RequestQueue queue = Volley.newRequestQueue(Activity5.this);
        String url3="http://"+IP_address+":3000/get_shop?s_id="+id;
        JSONArray jsonAr3 = new JSONArray();
        JsonArrayRequest example_3 = new JsonArrayRequest(Request.Method.GET, url3, jsonAr3,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        Toast.makeText(Activity5.this, "Connected to get_shops_category", Toast.LENGTH_SHORT).show();
                        for (int j = 0; j < response.length(); j++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(j);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                p_shop_names.add(obj.getString("name"));
                                p_shop_admin.add(obj.getString("s_admin_id"));
                                item= new Item();
                                item.img_url = p_img.get(counter);
                                item.item_name = p_names.get(counter);
                                item.price = p_prices.get(counter);
                                item.shop_admin_id = p_shop_admin.get(counter);
                                //Log.v("gazarZEFT", item.shop_admin_id);
                                item.shop_name = p_shop_names.get(counter);
                                item.shop_id = p_shop_ids.get(counter);
                                products.add(item);
                                counter++;
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        if(counter == all)
                        {
                            list_h = new ArrayList<Item>(products);
                            Log.v("gazar1", String.valueOf(products));
                           // bar = (TextView) findViewById(R.id.textView_toolBar);
                          //  bar.setText("Explore");
                            adapter_list = new listview_act5(Activity5.this, list_h);
                            Vlist = (ListView) findViewById(R.id.p_list);
                            Vlist.setAdapter(adapter_list);

                            Vlist.setOnItemClickListener(new AdapterView.OnItemClickListener() { //Create new object
                                @Override // Override method in object
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    Log.v("Pressed", "" + position);
                                    Item i = products.get(position);
                                    Intent int1 = new Intent(Activity5.this, Activity11.class);
                                    int1.putExtra("item_name", i.item_name);
                                    int1.putExtra("shop_id", i.shop_id);
                                    Log.v("gazarZEFT", i.shop_admin_id);
                                    int1.putExtra("shop_admin_id", i.shop_admin_id);
                                    //call api get product info to get description and material
                                    startActivity(int1);
                                }
                            });
                        }
                    }
                },
                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Activity5.this, "Failed to connect to get_shops_category. Try again later.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        queue.add(example_3);

    }

    private void get_shop_horizontal(String id) {

        RequestQueue queue = Volley.newRequestQueue(Activity5.this);
        String url3="http://"+IP_address+":3000/get_shop?s_id="+id;
        JSONArray jsonAr3 = new JSONArray();
        JsonArrayRequest example_3 = new JsonArrayRequest(Request.Method.GET, url3, jsonAr3,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        Toast.makeText(Activity5.this, "Connected to get_shops_category", Toast.LENGTH_SHORT).show();

                        for (int j = 0; j < response.length(); j++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(j);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                mLocations.add(obj.getString("address"));
                                mOrders.add(obj.getString("no_orders"));
                                mNumbers.add(obj.getString("landline"));
                                mRatings.add(obj.getString("rating"));
                                mProfile.add(obj.getString("image_url"));
                                mNames.add(obj.getString("name"));
                                mshop_ids.add(obj.getString("s_id"));
                                Log.v("gazarSI", obj.getString("name"));
                                get_shop_images(obj.getString("name"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        Log.v("gazarLo", String.valueOf(mLocations));
                        Log.v("gazarO", String.valueOf(mOrders));
                        Log.v("gazarN", String.valueOf(mNumbers));
                        Log.v("gazarR", String.valueOf(mRatings));
                        Log.v("gazarP", String.valueOf(mProfile));
                        Log.v("gazarSN", String.valueOf(mNames));
                        Log.v("gazarV", String.valueOf(shop_name));
                    }
                },
                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Activity5.this, "Failed to connect to get_shops_category. Try again later.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        queue.add(example_3);
    }

    private void get_shop_images(String name){

        RequestQueue queue = Volley.newRequestQueue(Activity5.this);
        String url3="http://"+ IP_address +":3000/get_shop_images?name="+name;
        JSONArray jsonAr3 = new JSONArray();
        JsonArrayRequest example_3 = new JsonArrayRequest(Request.Method.GET, url3, jsonAr3,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        Toast.makeText(Activity5.this, "Connected to get_shop_images", Toast.LENGTH_SHORT).show();
                        img_urls = new ArrayList<>();
                        for (int j = 0; j < response.length(); j++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(j);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                Log.v("gazarURL", String.valueOf(obj.getString("image_url")));
                                //if(shop_image != null && !shop_image .isEmpty())
                                //if(obj.getString("image_url") != null && !obj.getString("image_url").isEmpty())
                                if(!obj.getString("image_url").equals("NULL"))
                                {
                                    img_urls.add(obj.getString("image_url"));
                                    Log.v("gazaraya", "Not null");
                                }
                                else
                                {
                                    img_urls.add("https://www.freepik.com/free-photos-vectors/white");
                                    Log.v("gazaraya", "Null");
                                }
                                Log.v("gazarURLJ", img_urls.get(j));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        mImageUrls.add(img_urls);

                        counter_horizontal++;
                        Log.v("gazarURLS", String.valueOf(mImageUrls));

                        if(counter_horizontal == all_cats)
                            getImages();
                    }
                },
                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Activity5.this, "Failed to connect to get_shop_images. Try again later.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        queue.add(example_3);
    }

    private void get_product_categories(String id){
        RequestQueue queue = Volley.newRequestQueue(Activity5.this);
        String url3="http://"+IP_address+":3000/get_product_categories?id="+id;
        JSONArray jsonAr3 = new JSONArray();
        JsonArrayRequest example_3 = new JsonArrayRequest(Request.Method.GET, url3, jsonAr3,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        Toast.makeText(Activity5.this, "Connected to get_product_categories", Toast.LENGTH_SHORT).show();
                        all = response.length();
                        for (int j = 0; j < response.length(); j++) {
                            try {
                                item=new Item();
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(j);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                p_img.add(obj.getString("image_url"));
                                p_names.add(obj.getString("name"));
                                p_prices.add(obj.getString("price"));
                                p_shop_ids.add(obj.getString("shop_id"));
                                get_shop_veritcal(obj.getString("shop_id"));
                                //item.shop_name = shop_name;
                                //Log.v("gazarS", shop_name);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Activity5.this, "Failed to connect to get_product_categories. Try again later.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        queue.add(example_3);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.history:
                Intent int1 = new Intent(this, Activity8.class);
                startActivity(int1);
                finish();
                break;
            case R.id.favorite:
                Intent int2 = new Intent(this, Activity7.class);
                startActivity(int2);
                finish();
                break;
            case R.id.cart:
                Intent int3 = new Intent(this, Activity9.class);
                startActivity(int3);
                finish();
                break;
            case R.id.categories:
                Intent int4 = new Intent(this, Activity15.class);
                startActivity(int4);
                finish();
                break;


            case R.id.editprofile:
            {
                Intent i3 = new Intent(Activity5.this, Activity14.class);
                startActivity(i3);
            }
            break;

            case R.id.logout_button:       // logout button
            {
                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                        .putBoolean("iskeepMeLoggedin", false).commit();

                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                        .putBoolean("isLoggedinBefore", false).commit();

                getSharedPreferences("Customer_token", MODE_PRIVATE).edit()
                        .remove("token").commit();

                Intent i = new Intent(Activity5.this, MainActivity.class);
                startActivity(i);
                finish();
            }
            break;


            case R.id.bar_back_button:
                onBackPressed();
                break;

        }
    }


    ////////
}

