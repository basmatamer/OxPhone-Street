package com.example.lenovo.project_7_8_2018_;

import android.app.Activity;
import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

public class Activity7 extends AppCompatActivity implements View.OnClickListener {


    View clickSource;
    View touchSource;

    int offset = 0;

    Button bar_back_button;

    ///////////////////////habiba//////////////////////////////////
    JSONObject obj;
    String p_id;
    Item item;
    ArrayList<Item> products = new ArrayList<Item>();
    String s_id, shop_admin;
    listview_act7 adapter_list;
    ListView Vlist;
    ArrayList<String> ids = new ArrayList<>();
    ArrayList<String> shop_admin_ids = new ArrayList<>();
    ArrayList<String> shop_admin_1 = new ArrayList<>();
    ArrayList<String> shop_admin_2 = new ArrayList<>();
    ArrayList<String> shop_admin_3 = new ArrayList<>();
    Integer all;
    ArrayList<FavPage> arr = new ArrayList<>();
    ArrayList<FavPage> list_h;
    TextView bar;
    //String IP_address="192.168.1.7";
    String IP_address;
    FavPage f;
    Integer counter = 0;
    /////////////////////////habibaa/////////////////////////////

    Item[] arrall = {};
    ArrayList<Item> arr1 = new ArrayList<Item>();
    ArrayList<Item> arr2 = new ArrayList<Item>();
    ArrayList<Item> arr3 = new ArrayList<Item>();

    listview_act7_1 adapter_list1;
    ListView Vlist1;
    ArrayList<Item> list_h1;

    listview_act7_1 adapter_list2;
    ListView Vlist2;
    ArrayList<Item> list_h2;

    listview_act7_1 adapter_list3;
    ListView Vlist3;
    ArrayList<Item> list_h3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_7);

        IP_address = getSharedPreferences("IP_ADDRESS", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("ip_address", "aya");

        View t=findViewById(R.id.toolbar2);
        Button b= (Button) findViewById(R.id.favorite) ;
        b.setBackground(this.getResources().getDrawable(R.drawable.favorites_p));
        new navbar().create((DrawerLayout) this.findViewById(R.id.drawer_layout), Activity7.this);


        bar_back_button = (Button)findViewById(R.id.bar_back_button);
        bar_back_button.setOnClickListener(this);

        /////////////////////////////////////habiba///////////////////////////////////////
        String customer_ID = getSharedPreferences("Customer_token", MODE_PRIVATE).getString("token" ,"aya");
        get_fav_shops(customer_ID);
        /////////////////////////////////////habiba///////////////////////////////////////

        bar = (TextView) findViewById(R.id.textView_toolBar);
        bar.setText("Favorites");


        ///////////////////////////////BASMA//////////////////////////////////////
        get_fav_products(customer_ID);
    }

    private void basmas_lists()
    {
        divide();
        list_h1 = arr1;
        adapter_list1 = new listview_act7_1(this, list_h1);
        Vlist1 = (ListView) findViewById(R.id.c1);
        Vlist1.setAdapter(adapter_list1);
        Vlist1.setOnItemClickListener(new AdapterView.OnItemClickListener() { //Create new object
            @Override // Override method in object
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.v("Pressed", "" + position);
                Intent int1 = new Intent(Activity7.this, Activity11.class);
                Item item = arr1.get(position);
                int1.putExtra("item_name", item.item_name);
                int1.putExtra("shop_id", item.shop_id);
                int1.putExtra("shop_admin_id", shop_admin_1.get(position));
                if(item.item_name!="blank")
                    startActivity(int1);
            }
        });


        Vlist1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(touchSource == null)
                    touchSource = v;

                if(v == touchSource) {
                    Vlist2.dispatchTouchEvent(event);
                    if(event.getAction() == MotionEvent.ACTION_UP) {
                        clickSource = v;
                        touchSource = null;
                    }
                }

                if(v == touchSource) {
                    Vlist3.dispatchTouchEvent(event);
                    if(event.getAction() == MotionEvent.ACTION_UP) {
                        clickSource = v;
                        touchSource = null;
                    }
                }

                return false;
            }
        });

        Vlist1.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if(view == clickSource)
                    Vlist1.setSelectionFromTop(firstVisibleItem, view.getChildAt(0).getTop() + offset);
            }

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {}
        });






///////////////////////////////////////////////



        list_h2 = arr2;
        adapter_list2 = new listview_act7_1(this, list_h2);

        Vlist2 = (ListView) findViewById(R.id.c2);
        Vlist2.setAdapter(adapter_list2);
        Vlist2.setOnItemClickListener(new AdapterView.OnItemClickListener() { //Create new object
            @Override // Override method in object
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.v("Pressed", "" + position);
                Intent int1 = new Intent(Activity7.this, Activity11.class);
                Item item = arr2.get(position);
                int1.putExtra("item_name", item.item_name);
                int1.putExtra("shop_id", item.shop_id);
                int1.putExtra("shop_admin_id", shop_admin_2.get(position));
                if(item.item_name!="blank")
                    startActivity(int1);
            }
        });


        Vlist2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(touchSource == null)
                    touchSource = v;

                if(v == touchSource) {
                    Vlist1.dispatchTouchEvent(event);
                    if(event.getAction() == MotionEvent.ACTION_UP) {
                        clickSource = v;
                        touchSource = null;
                    }
                }

                if(v == touchSource) {
                    Vlist3.dispatchTouchEvent(event);
                    if(event.getAction() == MotionEvent.ACTION_UP) {
                        clickSource = v;
                        touchSource = null;
                    }
                }

                return false;
            }
        });

        Vlist2.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if(view == clickSource)
                    Vlist2.setSelectionFromTop(firstVisibleItem, view.getChildAt(0).getTop() + offset);
            }

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {}
        });



        ///////////////////////////////////////////////



        list_h3 = arr3;
        adapter_list3 = new listview_act7_1(this, list_h3);

        Vlist3 = (ListView) findViewById(R.id.c3);
        Vlist3.setAdapter(adapter_list3);
        Vlist3.setOnItemClickListener(new AdapterView.OnItemClickListener() { //Create new object
            @Override // Override method in object
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.v("Pressed", "" + position);
                Intent int1 = new Intent(Activity7.this, Activity11.class);
                Item item = arr3.get(position);
                int1.putExtra("item_name", item.item_name);
                int1.putExtra("shop_id", item.shop_id);
                int1.putExtra("shop_admin_id", shop_admin_3.get(position));
                if(item.item_name!="blank")
                    startActivity(int1);
            }
        });

        Vlist3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(touchSource == null)
                    touchSource = v;

                if(v == touchSource) {
                    Vlist1.dispatchTouchEvent(event);
                    if(event.getAction() == MotionEvent.ACTION_UP) {
                        clickSource = v;
                        touchSource = null;
                    }
                }

                if(v == touchSource) {
                    Vlist2.dispatchTouchEvent(event);
                    if(event.getAction() == MotionEvent.ACTION_UP) {
                        clickSource = v;
                        touchSource = null;
                    }
                }

                return false;
            }
        });

        Vlist3.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if(view == clickSource)
                    Vlist3.setSelectionFromTop(firstVisibleItem, view.getChildAt(0).getTop() + offset);
            }

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {}
        });

    }

    private void get_fav_shops(String customer_ID)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/get_fav_shops?cus_id="+customer_ID;
        JSONArray jsonAr = new JSONArray();
        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //requestSmsPermission();
                        //Toast.makeText(Activity7.this, "Connected to get_fav_shops", Toast.LENGTH_SHORT).show();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                s_id = obj.getString("favorites_s_id");
                                ids.add(s_id);
                                get_shop(s_id);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity7.this, "Failed to connect to get_fav_shops. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void get_shop(String id)
    {
        RequestQueue queue = Volley.newRequestQueue(Activity7.this);
        String url3="http://"+IP_address+":3000/get_shop?s_id="+id;
        JSONArray jsonAr3 = new JSONArray();
        JsonArrayRequest example_3 = new JsonArrayRequest(Request.Method.GET, url3, jsonAr3,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //Toast.makeText(Activity7.this, "Connected to get_shops_category", Toast.LENGTH_SHORT).show();
                        for (int j = 0; j < response.length(); j++) {
                            try {
                                f= new FavPage();
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(j);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                f.location = obj.getString("address");
                                f.orders = obj.getString("no_orders");
                                f.img_url= obj.getString("image_url");
                                f.phone = obj.getString("landline");
                                f.rating = obj.getString("rating");
                                arr.add(f);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        list_h = new ArrayList<FavPage>(arr);
                        adapter_list = new listview_act7(Activity7.this, list_h);
                        Vlist = (ListView) findViewById(R.id.p_list);
                        bar = (TextView) findViewById(R.id.textView_toolBar);
                        bar.setText("Favorites");
                        Vlist.setAdapter(adapter_list);
                        Vlist.setOnItemClickListener(new AdapterView.OnItemClickListener() { //Create new object
                            @Override // Override method in object
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                Log.v("Pressed", "" + position);
                                Toast.makeText(Activity7.this, "Pressed", Toast.LENGTH_SHORT).show();
                                Intent int1 = new Intent(Activity7.this, Activity10.class);
                                int1.putExtra("shop_id",ids.get(position));
                                startActivity(int1);
                            }
                        });
                    }
                },
                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Activity7.this, "Failed to connect to get_shops_category. Try again later.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        queue.add(example_3);
    }

    private void divide()
    {
        for (int i=0;i<products.size();i++)
        {
            if(i%3==0)
            {
                arr1.add(products.get(i));
                shop_admin_1.add(shop_admin_ids.get(i));
            }
            else if (i%3==1)
            {
                arr2.add(products.get(i));
                shop_admin_2.add(shop_admin_ids.get(i));
            }
            else
            {
                arr3.add(products.get(i));
                shop_admin_3.add(shop_admin_ids.get(i));
            }

        }

        //blanks
        Item blank= new Item();
        blank.item_name="blank";
        blank.img_url="https://www.freepik.com/free-photos-vectors/white";
        if(arr1.size()>arr2.size())
            arr2.add(blank);

        if(arr2.size()>arr3.size())
            arr3.add(blank);
    }

    private void get_fav_products(String customer_ID)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/get_fav_products?cus_id="+customer_ID;
        JSONArray jsonAr = new JSONArray();
        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity7.this, "Connected to get_fav_products", Toast.LENGTH_SHORT).show();
                        all = response.length();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                p_id = obj.getString("favorites_p_id");
                                Log.v("gazarPID", p_id);
                                get_product_info(p_id);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity7.this, "Failed to connect to get_fav_products. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void get_product_info(String id)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/get_product_info?p_id="+id;
        JSONObject jsonAr = new JSONObject();
        JsonObjectRequest jsonArRequest = new JsonObjectRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONObject>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        //requestSmsPermission();
                        try {
                            item = new Item();
                            item.item_name = response.getString("name");
                            item.img_url = response.getString("image_url");
                            item.shop_id = response.getString("shop_id");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Log.v("gazarSID", item.shop_id);
                        get_shop_product(item.shop_id);
                        products.add(item);
                        Toast.makeText(Activity7.this, "Connected to get_product_info", Toast.LENGTH_SHORT).show();


                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity7.this, "Failed to connect to get_product_info. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void get_shop_product(String id)
    {
        RequestQueue queue = Volley.newRequestQueue(Activity7.this);
        String url3="http://"+IP_address+":3000/get_shop?s_id="+id;
        JSONArray jsonAr3 = new JSONArray();
        JsonArrayRequest example_3 = new JsonArrayRequest(Request.Method.GET, url3, jsonAr3,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //Toast.makeText(Activity7.this, "Connected to get_shops_category", Toast.LENGTH_SHORT).show();
                        for (int j = 0; j < response.length(); j++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(j);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                shop_admin_ids.add(obj.getString("s_admin_id"));
                                counter++;
                                Log.v("gazarSSID", obj.getString("s_admin_id"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        if(counter == all)
                        {
                            basmas_lists();
                        }
                    }
                },
                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Activity7.this, "Failed to connect to get_shops_category. Try again later.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        queue.add(example_3);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.history:
                Intent int1 = new Intent(this, Activity8.class);
                startActivity(int1);
                finish();
                break;
            case R.id.explore:
                Intent int2 = new Intent(this, Activity5.class);
                startActivity(int2);
                finish();
                break;
            case R.id.cart:
                Intent int3 = new Intent(this, Activity9.class);
                startActivity(int3);
                finish();
                break;
            case R.id.itemsss:
                findViewById(R.id.p_list).setVisibility(View.GONE);
                findViewById(R.id.i_list).setVisibility(View.VISIBLE);
                findViewById(R.id.ps).setVisibility(View.INVISIBLE);
                findViewById(R.id.is).setVisibility(View.VISIBLE);
                break;
            case R.id.pagesss:
                findViewById(R.id.p_list).setVisibility(View.VISIBLE);
                findViewById(R.id.i_list).setVisibility(View.GONE);
                findViewById(R.id.ps).setVisibility(View.VISIBLE);
                findViewById(R.id.is).setVisibility(View.INVISIBLE);
                break;
            case R.id.categories:
                Intent int5 = new Intent(this, Activity15.class);
                startActivity(int5);
                break;


            case R.id.editprofile:
            {
                Intent i3 = new Intent(Activity7.this, Activity14.class);
                startActivity(i3);
            }
            break;

            case R.id.logout_button:       // logout button
            {

                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                        .putBoolean("iskeepMeLoggedin", false).commit();

                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                        .putBoolean("isLoggedinBefore", false).commit();


                getSharedPreferences("Customer_token", MODE_PRIVATE).edit()
                        .remove("token").commit();

                Intent i = new Intent(Activity7.this, MainActivity.class);
                startActivity(i);
                finish();
            }
            break;

            case R.id.bar_back_button:
                onBackPressed();
                break;



        }
    }



}
