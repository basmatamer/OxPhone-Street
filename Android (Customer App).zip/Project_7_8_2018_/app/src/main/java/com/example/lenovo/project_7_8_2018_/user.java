package com.example.lenovo.project_7_8_2018_;

public class user {

    int ID=0;
    String name= "Basma Tamer";
    String phone="01020040476";
    String email= "basmatamer@aucegupt.edu";
    String add="Villa G5, Grand Residence, New Cairo, Cairo, Egypt";
}
