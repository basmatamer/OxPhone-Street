package com.example.lenovo.project_7_8_2018_;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;


public class navbar {

    user me= new user(); //Set me to the user info from shared preferences
    private DrawerLayout mDrawerLayout;
    ArrayList<MenuItem> cat= new ArrayList<MenuItem>();

    // mDrawerLayout.bringToFront();


//     NavigationView navigationView = mDrawerLayout.findViewById(R.id.nav_view);
//     View headerView = navigationView.getHeaderView(0);
//     Menu menu = navigationView.getMenu();
//     Menu newmenu=menu.addSubMenu("");

     int counter;

    ArrayList<String> mEntries = new ArrayList<String>();

    public void create(final DrawerLayout v, final Context context)//DrawerLayout dr, NavigationView nv)
    {
        mDrawerLayout = (DrawerLayout) v.findViewById(R.id.drawer_layout);
        final NavigationView navigationView = mDrawerLayout.findViewById(R.id.nav_view);
        final View headerView = navigationView.getHeaderView(0);
        Menu menu = navigationView.getMenu();
        final Menu newmenu=menu.addSubMenu(0, Menu.FIRST, Menu.NONE,"");

        //mDrawerLayout = (DrawerLayout) v.findViewById(R.id.drawer_layout);
        //mDrawerLayout =  v;
        //final ArrayList<MenuItem> cat= new ArrayList<MenuItem>();

        // mDrawerLayout.bringToFront();


        //final NavigationView navigationView = mDrawerLayout.findViewById(R.id.nav_view);
        //final View headerView = navigationView.getHeaderView(0);
        //final Menu menu = navigationView.getMenu();
        cat.add(menu.findItem(R.id.accessories)); cat.add(menu.findItem(R.id.beauty));
        cat.add(menu.findItem(R.id.food));cat.add(menu.findItem(R.id.clothes));

        setter(headerView,context);

        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        menuItem.setChecked(true);


                        final String IP_address = context.getSharedPreferences("IP_ADDRESS", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                                .getString("ip_address", "aya");;
                        String category_id;



                        switch (menuItem.getItemId())
                        {
                            case R.id.food:
                                category_id = "1";
                                break;

                            case R.id.clothes:
                                category_id = "2";
                                break;

                            case R.id.accessories:
                                category_id = "3";
                                break;

                            case R.id.beauty:
                                category_id = "4";
                                break;

                            default:
                                category_id = "0";   // just indication eno mada5alsh f ay wa7da mn el fo2
                        }

                        ///////////////////////////////////////////////
                        if(menuItem.getItemId()==R.id.accessories||menuItem.getItemId()==R.id.beauty||
                                menuItem.getItemId()==R.id.food||menuItem.getItemId()==R.id.clothes)
                        {

                            TextView x = (TextView) headerView.findViewById(R.id.textView7);
                            x.setText("Pick a Shop");

                            // Call API to get the shop names of all shops in this category
                            // This API returns a JSONArray of all shops IDs in this category

                            /////////////////////////////////////////

                            RequestQueue queue = Volley.newRequestQueue(context);
                            JSONArray jsonAr = new JSONArray();
                            String gurl = "http://" + IP_address + ":3000/get_shops_of_chosen_category?cat_id=" + category_id;

                            //JSONObject obj;
                            //String shop_id;

                            //Menu newmenu=menu.addSubMenu("");

                            JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, gurl, jsonAr,
                                    new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                                    {
                                        JSONObject obj;
                                        String shop_id;

                                        //Menu newmenu=menu.addSubMenu("");

                                        //mEntries = new ArrayList<String>();

                                        @Override
                                        public void onResponse(JSONArray response) {
                                            counter = 0;

                                            Toast.makeText(context, "Connected to getting IDs of shops", Toast.LENGTH_SHORT).show();
                                            for (int i = 0; i < response.length(); i++) {
                                                try {

                                                    obj = new JSONObject();
                                                    try {
                                                        obj = response.getJSONObject(i);
                                                    } catch (JSONException e) {
                                                        e.printStackTrace();
                                                    }

                                                    shop_id = obj.getString("RelationshopID");



                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }

                                                mEntries.add(shop_id);

                                                /////////////////////////////// Calling the API that takes shop ID and returns shop name

                                                RequestQueue queue3 = Volley.newRequestQueue(context);
                                                StringRequest example3 = new StringRequest(Request.Method.GET,
                                                        "http://" + IP_address + ":3000/get_shop_name_of_chosen_category?s_id=" + shop_id,
                                                        new Response.Listener<String>() {
                                                            @Override
                                                            public void onResponse(String response) {
                                                                // Toast.makeText(Activity3.this,"Successfully retreived customer ID", Toast.LENGTH_SHORT).show();
                                                                newmenu.add(0,counter,Menu.NONE,response);
                                                            }
                                                        },
                                                        new Response.ErrorListener()
                                                        {
                                                            @Override
                                                            public void onErrorResponse(VolleyError error)
                                                            {
                                                                Toast.makeText(context, "Problem in retreiving customer ID", Toast.LENGTH_SHORT).show();

                                                            }
                                                        }
                                                );


                                                queue3.add(example3);

                                                counter = counter +1;
                                            }////////////////////////////    // end of the for loop
                                        }
                                    },

                                    new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                                    {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            Toast.makeText(context, "Failed to connect to IDs of shops.", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                            );
                            queue.add(jsonArRequest);

                            //////////////////////////////////////////////////////////



                            for(int i=0;i<cat.size();i++)
                                cat.get(i).setVisible(false);


                            navigationView.invalidate();
                        }
                        else
                        {


                            if((menuItem.getItemId() & counter) == counter)
                                for( int k = 0; k < newmenu.size(); k++)
                                {
                                    if(newmenu.getItem(k).getItemId() == menuItem.getItemId())
                                    {
                                        //mDrawerLayout.closeDrawers();
                                       // for(int i=0;i<cat.size();i++)
                                        //    cat.get(i).setVisible(true);

                                        Intent intent = new Intent(context, Activity10.class);
                                        intent.putExtra("shop_id", mEntries.get(k));
                                        Log.v("gazarNav0", String.valueOf(newmenu.getItem(k).getItemId()));
                                        Log.v("gazarNav1",  String.valueOf(mEntries));
                                        Log.v("gazarNav2",  String.valueOf(k));

                                        for (int i=0;i<newmenu.size();i++)
                                            newmenu.removeItem(i);

                                        context.startActivity(intent);
                                        break;
                                    }
                                }
//                            mDrawerLayout.closeDrawers();
//                            for(int i=0;i<cat.size();i++)
//                                cat.get(i).setVisible(true);
//
//                            for (int i=0;i<newmenu.size();i++)
//                                newmenu.removeItem(i);
//
//                            Intent intent = new Intent(context, Activity10.class);
//                            intent.putExtra("shop_id", "8");
//                            context.startActivity(intent);
                        }

                        /////////////////////////////////////////////////////////////////////

                        return true;
                    }
                });

    }



    private void setter(View v, final Context c)
    {
       final TextView textname = (TextView)v.findViewById(R.id.name);
        final TextView textadd= (TextView)v.findViewById(R.id.address);
       final  TextView textphone = (TextView)v.findViewById(R.id.phone);
        final TextView textemail = (TextView)v.findViewById(R.id.email);
        final ImageView profile_pic = (ImageView)v.findViewById(R.id.profile_pic);



        String IP_address = c.getSharedPreferences("IP_ADDRESS", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("ip_address", "aya");

        String customer_ID = c.getSharedPreferences("Customer_token", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("token", "aya");


        /////////// Will call API that returns a JSON Object of all info about this person
        //// Must check whether feeh URL wla NULL

        RequestQueue queue = Volley.newRequestQueue(c);
        JSONObject jsonob = new JSONObject();
        JsonObjectRequest jsonobRequest  = new JsonObjectRequest(Request.Method.GET, "http://" + IP_address+ ":3000/get_profile_info?customer_ID=" + customer_ID
                , jsonob,
                new Response.Listener<JSONObject>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        Toast.makeText(c, "Retreiving profile Details", Toast.LENGTH_SHORT).show();

                        try {

                            String image_url = response.getString("image_url");

                           if(image_url != null && !image_url .isEmpty())
                                Picasso.with(c).load(image_url).fit().centerInside().into(profile_pic);


                            textname.setText(response.getString("name"));
                            textadd.setText(response.getString("address"));
                            textphone.setText(response.getString("mobilenumber"));
                            textemail.setText(response.getString("email"));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }




                    }},new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                Toast.makeText(c, "Failed to retreive profile Details", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonobRequest);



        //////////////////////////////////////////////////////
//        TextView textname = (TextView)v.findViewById(R.id.name);
//        textname.setText(me.name);
//
//        String add= me.add.substring(0,20)+"...";
//        TextView textadd= (TextView)v.findViewById(R.id.address);
//        textadd.setText(add);
//
//        TextView textphone = (TextView)v.findViewById(R.id.phone);
//        textphone.setText(me.phone);
//
//        TextView textemail = (TextView)v.findViewById(R.id.email);
//        textemail.setText(me.email);


    }








}
