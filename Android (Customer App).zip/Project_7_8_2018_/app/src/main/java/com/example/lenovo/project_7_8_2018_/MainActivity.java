package com.example.lenovo.project_7_8_2018_;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button login;
    Button logo_sign_up;
    Button facebook_sign_up;
    Button google_sign_up;
    SharedPreferences shared;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        shared = getSharedPreferences("IP_ADDRESS", Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = shared.edit();
        editor.putString("ip_address", "10.40.39.125");
        editor.commit();



        // STILL TO BE CHANGED !!!!!!!!
        Boolean isRegistered = getSharedPreferences("PREFERENCE", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getBoolean("isRegistered", false);

        Boolean iskeepMeLoggedin = getSharedPreferences("PREFERENCE", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getBoolean("iskeepMeLoggedin", false);

        Boolean isLoggedinBefore = getSharedPreferences("PREFERENCE", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getBoolean("isLoggedinBefore", false);

        ///////////////////////////////



        if(isRegistered & !iskeepMeLoggedin)
        {
            startActivity(new Intent(MainActivity.this, Activity3.class));   // move to login screen
            Toast.makeText(MainActivity.this, "Needs to login now", Toast.LENGTH_LONG)
                        .show();
                finish();
        }

        if(!isRegistered && iskeepMeLoggedin)
        {
            Toast.makeText(MainActivity.this, "Has logged in before", Toast.LENGTH_LONG)
                    .show();
            startActivity(new Intent(MainActivity.this, Activity5.class));   // move to Explore Activity 3la tool since he's already logged in

            finish();
        }


        if(isRegistered & iskeepMeLoggedin)
        {
            Toast.makeText(MainActivity.this, "Has logged in before", Toast.LENGTH_LONG)
                    .show();
            startActivity(new Intent(MainActivity.this, Activity5.class));   // move to Explore Activity 3la tool since he's already logged in

            finish();
        }


        login = (Button) findViewById(R.id.login);
        logo_sign_up = (Button) findViewById(R.id.logo_signup);
        facebook_sign_up = (Button) findViewById(R.id.facebook_signup);
        google_sign_up = (Button) findViewById(R.id.gmail_signup);


        login.setOnClickListener(this);
        logo_sign_up.setOnClickListener(this);
        facebook_sign_up.setOnClickListener(this);
        google_sign_up.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {   /// ASSUME FOR NOW THAT FACEBOOK BUTTON TAKES U TO EDIT PROFILE

            case R.id.login:
                Intent i = new Intent(MainActivity.this, Activity3.class);
                startActivity(i);
                //finish();
                break;


            /*
            case R.id.facebook_signup:

                break;
            */

            /*
            case R.id.gmail_signup:
                break;

            */

            case R.id.logo_signup: {
                Intent i2 = new Intent(MainActivity.this, Activity2.class);
                startActivity(i2);
                //finish();
            }
            break;

        }


    }
}