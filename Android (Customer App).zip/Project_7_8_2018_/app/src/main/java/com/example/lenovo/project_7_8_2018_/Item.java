package com.example.lenovo.project_7_8_2018_;

public class Item {
    String shop_name="";
    String shop_id="";
    String shop_admin_id="";
    String item_name="";
    String price="";
    String img_url="";
}
