package com.example.lenovo.project_7_8_2018_;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

import static android.provider.DocumentsContract.isDocumentUri;

public class Activity14 extends AppCompatActivity implements View.OnClickListener{

    Button bar_back_button;
    Button back;
    Button save;
    Button upload;

    TextView tool_bar_text;

    ImageView dp;

    String image_url;
    Boolean is_upload = false;

    EditText new_name;
    EditText new_email;
    EditText new_password;
    EditText new_confirm_password;
    EditText new_mobilenumber;
    EditText new_address;


    private static final String IMAGE_DIRECTORY = "/Camera";
    private int GALLERY = 1, CAMERA = 2;

    String yala_path;

    String yarab_path;

    String customer_ID;


    //String IP_address ="192.168.1.7" ;
    String IP_address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_14);

        IP_address = getSharedPreferences("IP_ADDRESS", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("ip_address", "aya");


        is_upload = false;

        bar_back_button = (Button) findViewById(R.id.bar_back_button);
        back = (Button) findViewById(R.id.back);
        save = (Button) findViewById(R.id.edit_save);
        upload = (Button) findViewById(R.id.upload);
        dp = (ImageView)findViewById(R.id.dp);

        tool_bar_text = (TextView) findViewById(R.id.textView_toolBar);
        tool_bar_text.setText("Edit Profile");


        new_name = (EditText) findViewById(R.id.name_tv);
        new_email = (EditText) findViewById(R.id.email_tv);
        new_password = (EditText) findViewById(R.id.password_tv);
        new_confirm_password = (EditText) findViewById(R.id.confirmpassword_tv);
        new_mobilenumber = (EditText) findViewById(R.id.mobilenumber_tv);
        new_address = (EditText) findViewById(R.id.address_tv);


        bar_back_button.setOnClickListener(this);
        back.setOnClickListener(this);
        save.setOnClickListener(this);
        upload.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){

            case R.id.bar_back_button:
                onBackPressed();
                break;

            case R.id.back:
            {
                onBackPressed();
            }
                break;

            case R.id.edit_save: {

                customer_ID = getSharedPreferences("Customer_token", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                        .getString("token", "aya");

                Toast.makeText(Activity14.this, customer_ID, Toast.LENGTH_SHORT).show();

                if (new_password.getText().toString().equals(new_confirm_password.getText().toString()) && !(new_name.getText().toString().isEmpty()) && !(new_email.getText().toString().isEmpty()) && !(new_mobilenumber.getText().toString().isEmpty()) && !(new_address.getText().toString().isEmpty())
                        && !(new_password.getText().toString().isEmpty())) {
                    RequestQueue queue = Volley.newRequestQueue(Activity14.this);
                    StringRequest example = new StringRequest(Request.Method.GET,
                            "http://" + IP_address + ":3000/edit_profile?newname=" + new_name.getText().toString() + "&email=" + new_email.getText().toString() + "&password=" + new_password.getText().toString()
                                    + "&mobilenumber=" + new_mobilenumber.getText().toString() + "&address=" + new_address.getText().toString() + "&customer_ID=" + customer_ID,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(Activity14.this, "Successfully updated Profile", Toast.LENGTH_SHORT).show();

                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(Activity14.this, "Problem in updating Profile", Toast.LENGTH_SHORT).show();

                                }
                            }
                    );


                    queue.add(example);
                } else {
                    Toast.makeText(Activity14.this, "Invalid or empty fields! Please Try Again!", Toast.LENGTH_LONG).show();
                }


                if (is_upload == true) {   // an image was uploaded, so will save it to DB

                    ///////////////////////////////////////////////

                    //////////////////////////////////////////////////////////////
                    RequestQueue queue4 = Volley.newRequestQueue(this);

                    StringRequest example4 = new StringRequest(Request.Method.GET,
                            "http://" + IP_address + ":3000/uploadImage?path=" + "C:/Users/Lenovo/Desktop/ProjectProfiles/aya.jpg",
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(Activity14.this, "Successful Upload", Toast.LENGTH_SHORT).show();
                                    image_url = response;
                                    Toast.makeText(Activity14.this, "image_url is:"+image_url, Toast.LENGTH_SHORT).show();

                                    ////////////////////////////////////////////////
                                    RequestQueue queue2 = Volley.newRequestQueue(Activity14.this);
                                    StringRequest example2 = new StringRequest(Request.Method.GET,
                                            "http://" + IP_address + ":3000/update_image?url=" + image_url + "&customer_ID=" + customer_ID,
                                            new Response.Listener<String>() {
                                                @Override
                                                public void onResponse(String response) {
                                                    Toast.makeText(Activity14.this, "Successfully updated image url to DB", Toast.LENGTH_SHORT).show();

                                                }
                                            },
                                            new Response.ErrorListener() {
                                                @Override
                                                public void onErrorResponse(VolleyError error) {
                                                    Toast.makeText(Activity14.this, "Problem in updating DB", Toast.LENGTH_SHORT).show();

                                                }
                                            }
                                    );


                                    queue2.add(example2);
                                    ////////////////////////////////////////

                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(Activity14.this, "Unsuccessful Upload", Toast.LENGTH_SHORT).show();

                                }
                            }
                    );

                    queue4.add(example4);

                    /////////////////////////////////////////////////////////////

                }
            }
            break;

            case R.id.upload:
            {
                ////////////////////////////////////////////

               // showPictureDialog();
                choosePhotoFromGallery();


                ///////////////////////////////////////////
            }
            break;
        }


    }
    //////////////////////////////////////////////////////

    /*
    private void showPictureDialog(){
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("Select Action");
        pictureDialog.setIcon(R.drawable.logoreg);
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Capture photo from camera" };
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                choosePhotoFromGallery();
                                break;
                            case 1:
                                takePhotoFromCamera();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }
    */

    public void choosePhotoFromGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(galleryIntent, GALLERY);
    }

    private void takePhotoFromCamera() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                Uri contentURI = data.getData();

               File my_file = new File(getRealPathFromURI(contentURI));
               yarab_path = my_file.getPath();
                Uri.fromFile(new File(yarab_path));
                Log.v("yarab path", Uri.fromFile(new File(yarab_path)).toString());
                is_upload = true;


                Toast.makeText(Activity14.this, my_file.getPath(), Toast.LENGTH_SHORT).show();


                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), contentURI);
                    Toast.makeText(Activity14.this, yarab_path, Toast.LENGTH_SHORT).show();
                    // Toast.makeText(Activity14.this, "Image Saved!", Toast.LENGTH_SHORT).show();
                    dp.setImageBitmap(bitmap);

                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(Activity14.this, "Failed!", Toast.LENGTH_SHORT).show();
                }
            }

        } else if (requestCode == CAMERA) {
            Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
            dp.setImageBitmap(thumbnail);


            Toast.makeText(Activity14.this, yala_path, Toast.LENGTH_SHORT).show();
        }

    }


    private String getRealPathFromURI(Uri contentURI) {
        String result;
        Cursor cursor = getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) { // Source is Dropbox or other similar local file path
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }



}
