package com.example.lenovo.project_7_8_2018_;

public class FavPage {
    String location;
    String phone;
    String orders;
    String img_url;
    String rating;
}
