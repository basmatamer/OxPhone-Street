package com.example.lenovo.project_7_8_2018_;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Activity15 extends AppCompatActivity  implements View.OnClickListener{

    listview_cat adapter_list;
    ListView Vlist;
    ArrayList<Category_Stuff> arr = new ArrayList<>();
    ArrayList<Category_Stuff> list_h;
    TextView bar;

    //String IP_address="192.168.1.7";
    String IP_address;
    String customer_ID;

    Category_Stuff f;
    JSONObject obj;
    String category_id;
    Integer counter=0;
    ArrayList<String> ids = new ArrayList<>();
    View convertView;

    Button cat_next;

    Button bar_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_15);

        IP_address = getSharedPreferences("IP_ADDRESS", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("ip_address", "aya");

        cat_next = (Button) findViewById(R.id.back);
        cat_next.setOnClickListener(this);

        bar_back = (Button)findViewById(R.id.bar_back_button);
        bar_back.setOnClickListener(this);

        all_cat();
        customer_ID= getSharedPreferences("Customer_token", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("token", "aya");
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        get_cat(customer_ID);
        list_h = new ArrayList<Category_Stuff>(arr);
        adapter_list = new listview_cat(Activity15.this, list_h);
        Vlist = (ListView) findViewById(R.id.listview);
        bar = (TextView) findViewById(R.id.textView_toolBar);
        bar.setText("Category");
        Vlist.setAdapter(adapter_list);
        Vlist.setDivider(getResources().getDrawable(android.R.color.transparent));
        Vlist.setDividerHeight(20);
        Vlist.setOnItemClickListener(new AdapterView.OnItemClickListener() { //Create new object
            @Override // Override method in object
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.v("Pressed", "" + position);
                //Log.v("gazarV", String.valueOf(arr.indexOf(f)));
                Toast.makeText(Activity15.this, String.valueOf(position), Toast.LENGTH_SHORT).show();
                Category_Stuff c = arr.get(position);
                c.checked = !c.checked;
                c.ck.setChecked(c.checked);
                //adapter_list.ck.setChecked(c.checked);
                switch (String.valueOf(position))
                {
                    case "0":
                        category_id = "1";
                        break;

                    case "1":
                        category_id = "2";
                        break;

                    case "2":
                        category_id = "3";
                        break;

                    case "3":
                        category_id = "4";
                        break;
                    case "4":
                        category_id = "5";
                        break;
                    case "5":
                        category_id = "6";
                        break;
                    case "6":
                        category_id = "7";
                        break;
                }
                if(c.checked == true)
                {
                    add_cat(customer_ID, category_id);
                }
                else
                {
                    delete_cat(customer_ID, category_id);
                }
            }
        });
    }

    private void all_cat()
    {
        Category_Stuff a = new Category_Stuff();
        a.cat_name = "Food";
        a.checked = false;
        arr.add(a);
        Log.v("gazarV", String.valueOf(arr.indexOf(a)));

        Category_Stuff g = new Category_Stuff();
        g.cat_name = "Clothes";
        g.checked = false;
        arr.add(g);
        Log.v("gazarV", String.valueOf(arr.indexOf(g)));

        Category_Stuff s = new Category_Stuff();
        s.cat_name = "Accessories";
        s.checked = false;
        arr.add(s);
        Log.v("gazarV", String.valueOf(arr.indexOf(s)));

        Category_Stuff c = new Category_Stuff();
        c.cat_name = "Beauty Products";
        c.checked = false;
        arr.add(c);
        Log.v("gazarV", String.valueOf(arr.indexOf(c)));

    }


    private void add_cat (String c_id, String cat_id)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/add_preferred_categories?customer_id="+c_id+"&category_id="+ cat_id;
        JSONObject jsonAr = new JSONObject();
        JsonObjectRequest jsonArRequest = new JsonObjectRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONObject>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity15.this, "Connected to add_cat", Toast.LENGTH_SHORT).show();

                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity15.this, "Failed to connect to add_cat. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void delete_cat (String c_id, String cat_id)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/delete_preferred_categories?customer_id="+c_id+"&category_id="+cat_id;
        JSONObject jsonAr = new JSONObject();
        JsonObjectRequest jsonArRequest = new JsonObjectRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONObject>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity15.this, "Connected to delete_cat", Toast.LENGTH_SHORT).show();

                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity15.this, "Failed to connect to delete_cat. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void get_cat(String id)
    {

        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/get_preferred_categories?customer_id="+id;
        JSONArray jsonAr = new JSONArray();
        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity15.this, "Connected to get_preferred_categories", Toast.LENGTH_SHORT).show();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                f = new Category_Stuff();
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                arr.get(Integer.valueOf(obj.getString("RelationCategoryID"))-1).checked = true;
                                Log.v("gazarV", String.valueOf(arr.get(Integer.valueOf(obj.getString("RelationCategoryID"))-1)));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        //getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity15.this, "Failed to connect to get_preferred_categories. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId())
        {
            case R.id.bar_back_button:
                onBackPressed();
            break;

            case R.id.back:
            {
                Intent int4 = new Intent(this, Activity5.class);
                startActivity(int4);
            }
            break;
        }

    }
}
