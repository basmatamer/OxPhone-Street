package com.example.lenovo.project_7_8_2018_;

import android.widget.CheckBox;

public class Category_Stuff {
    String cat_name;
    Boolean checked;
    CheckBox ck;
}
