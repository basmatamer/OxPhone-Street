package com.example.lenovo.project_7_8_2018_;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class listview_act7_1 extends ArrayAdapter<Item> {

    //private static final String TAG = "listview_act5";

    //vars
    List<Item> list_l;
    ArrayList<Item> list;


    public listview_act7_1(Context context, List<Item> list_l)
    {
        super(context, R.layout.list_act7_1, list_l);
        this.list_l = list_l;
        this.list = new ArrayList<Item>();
        this.list.addAll(list_l);
        Log.v("gazar", "constructor");
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        Log.v("gazar", "passed");
        if (convertView == null) // Was this cell rendered yet?
            convertView = LayoutInflater.
                    from(getContext()). // Which activity are we in right now
                    inflate(
                    R.layout.list_act7_1, // Desired layout - in your case, would be the custom XML
                    parent, // Just leave it as it is
                    false // Also leave it as it is
            );

        //Assume layout has imageView, titleView, subtitleView
        ImageView imgmain;
        TextView name, item, price;

        Item i = getItem(position);
        imgmain = (ImageView) convertView.findViewById(R.id.imgmain);


        if(i.img_url != null && !i.img_url .isEmpty())
            Picasso.with(getContext()).load(i.img_url).fit().centerInside().into(imgmain);

        return convertView;
    }


}
