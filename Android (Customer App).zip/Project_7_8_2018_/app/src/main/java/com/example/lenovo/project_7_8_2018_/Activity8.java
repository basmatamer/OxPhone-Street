package com.example.lenovo.project_7_8_2018_;

import android.content.Intent;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

public class Activity8 extends AppCompatActivity implements  View.OnClickListener {

    listview_act8 adapter_list;
    ListView Vlist;
    ArrayList<History> arr = new ArrayList<>();
    ArrayList<History> list_h;
    History f;
    TextView bar;
   // String IP_address="192.168.1.7";
    String IP_address;

    JSONObject obj;
    ArrayList<String> img_url=  new ArrayList<>();
    ArrayList<String> item_name=  new ArrayList<>();
    ArrayList<String> shop_name=  new ArrayList<>();
    ArrayList<String> price=  new ArrayList<>();
    ArrayList<String> order_date=  new ArrayList<>();
    ArrayList<String> shop_ids=  new ArrayList<>();
    Integer counter = 0;
    Integer all = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_8);

        new navbar().create((DrawerLayout) this.findViewById(R.id.drawer_layout), Activity8.this);

        bar = (TextView) findViewById(R.id.textView_toolBar);
        bar.setText("History");

        IP_address = getSharedPreferences("IP_ADDRESS", MODE_PRIVATE)   // this is Activity 1 if the app is just installed
                .getString("ip_address", "aya");

        String customer_ID = getSharedPreferences("Customer_token", MODE_PRIVATE).getString("token" ,"aya");

        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/get_history?cus_id=" +customer_ID;
        JSONArray jsonAr = new JSONArray();
        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity8.this, "Connected to get_history", Toast.LENGTH_SHORT).show();
                        all = response.length();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                //f= new History();
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                order_date.add(obj.getString("order_date").substring(0, obj.getString("order_date").indexOf('T')));
                                price.add(obj.getString("amount_paid"));
                                //f.order_date = obj.getString("order_date").substring(0, obj.getString("order_date").indexOf('T'));
                                //f.price = obj.getString("amount_paid");
                                get_product_history(obj.getString("history_p_id"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity8.this, "Failed to connect to get_history. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void get_product_history(String id)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url= "http://"+IP_address+":3000/get_product_history?p_id="+id;
        JSONArray jsonAr = new JSONArray();
        JsonArrayRequest jsonArRequest = new JsonArrayRequest(Request.Method.GET, url, jsonAr,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        //requestSmsPermission();
                        Toast.makeText(Activity8.this, "Connected to get_product_history", Toast.LENGTH_SHORT).show();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                item_name.add(obj.getString("name"));
                                img_url.add(obj.getString("image_url"));
                                //f.item_name = obj.getString("name");
                                //f.img_url = obj.getString("image_url");
                                get_shop(obj.getString("shop_id"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }, new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
        {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Activity8.this, "Failed to connect to get_product_history. Try again later.", Toast.LENGTH_SHORT).show();
            }
        }
        );
        queue.add(jsonArRequest);
    }

    private void get_shop(String id)
    {
        RequestQueue queue = Volley.newRequestQueue(Activity8.this);
        String url3="http://"+IP_address+":3000/get_shop?s_id="+id;
        JSONArray jsonAr3 = new JSONArray();
        JsonArrayRequest example_3 = new JsonArrayRequest(Request.Method.GET, url3, jsonAr3,
                new Response.Listener<JSONArray>() //This is an in-lined function that waits for a response from the server running ASYCHRONOUSLY.
                {
                    @Override
                    public void onResponse(JSONArray response) {
                        Toast.makeText(Activity8.this, "Connected to get_shops_category", Toast.LENGTH_SHORT).show();
                        for (int j = 0; j < response.length(); j++) {
                            try {
                                obj = new JSONObject();
                                try {
                                    obj = response.getJSONObject(j);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                shop_name.add(obj.getString("name"));
                                shop_ids.add(obj.getString("s_id"));
                                //f.shop_name = obj.getString("name");
                                //arr.add(f);
                                f= new History();
                                f.img_url = img_url.get(counter);
                                f.item_name = item_name.get(counter);
                                f.price = price.get(counter);
                                f.order_date = order_date.get(counter);
                                f.shop_name = shop_name.get(counter);
                                arr.add(f);
                                counter++;
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        if(counter == all) {
                            list_h = new ArrayList<History>(arr);
                            adapter_list = new listview_act8(Activity8.this, list_h);
                            Vlist = (ListView) findViewById(R.id.p_list);
                            bar = (TextView) findViewById(R.id.textView_toolBar);
                            bar.setText("History");
                            Vlist.setAdapter(adapter_list);
                            Vlist.setOnItemClickListener(new AdapterView.OnItemClickListener() { //Create new object
                                @Override // Override method in object
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    Log.v("Pressed", "" + position);
                                    Toast.makeText(Activity8.this, "Pressed", Toast.LENGTH_SHORT).show();
                                    Intent int1 = new Intent(Activity8.this, Activity10.class);
                                    History history = arr.get(position);
                                    int1.putExtra("shop_id", shop_ids.get(position));
                                    startActivity(int1);
                                }
                            });
                        }
                    }
                },
                new Response.ErrorListener() //This is an in-lined function that handles CONNECTION errors. Errors from the SERVER (i.e. wrong username/password, et cetera) should still be handled by Response.Listener.
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Activity8.this, "Failed to connect to get_shops_category. Try again later.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        queue.add(example_3);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.explore:
                Intent int1 = new Intent(this, Activity5.class);
                startActivity(int1);
                finish();
                break;
            case R.id.favorite:
                Intent int2 = new Intent(this, Activity7.class);
                startActivity(int2);
                finish();
                break;
            case R.id.cart:
                Intent int3 = new Intent(this, Activity9.class);
                startActivity(int3);
                finish();
                break;


            case R.id.categories:
                Intent int5 = new Intent(this, Activity15.class);
                startActivity(int5);

                break;


            case R.id.editprofile:
            {
                Intent i3 = new Intent(Activity8.this, Activity14.class);
                startActivity(i3);
            }
            break;

            case R.id.logout_button:       // logout button
            {

                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                        .putBoolean("iskeepMeLoggedin", false).commit();

                getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                        .putBoolean("isLoggedinBefore", false).commit();


                getSharedPreferences("Customer_token", MODE_PRIVATE).edit()
                        .remove("token").commit();

                Intent i = new Intent(Activity8.this, MainActivity.class);
                startActivity(i);
                finish();
            }
            break;

        }
    }
}
